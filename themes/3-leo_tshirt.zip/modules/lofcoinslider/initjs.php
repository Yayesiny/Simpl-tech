<script type="text/javascript">
// $.noConflict();
$(document).ready( function(){	
	var currentLink = "";
	var nivoLink = "";
	$('#lofcs-full3d-<?php echo $prfSlide.$blockid;?>').nivoSlider({
		effect:'<?php echo $params->get('effect', 'random');?>',
		animSpeed:<?php echo (int)$params->get('duration', 500);?>,
		pauseTime:<?php echo (int)$params->get('interval', 3000);?>,
		slices:<?php echo (int) $params->get('slices',20);?>,
		startSlide:<?php echo (int) $params->get('start_item',0);?>,
		directionNavHide:<?php echo (int) $params->get('direc_nav_hide',1);?>,
		enableCaption :'<?php echo $params->get('enable_caption',1);?>',		
		captionOpacity:'<?php echo $params->get('caption_opacity',0.8);?>',
		captionBackground:'<?php echo $params->get('caption_bg','#C01F25');?>',
		group:'<?php echo $params->get('module_group','product');?>',
		directionNav:<?php echo (int)$params->get('direction_nav',1);?>,
		manualAdvance:<?php echo (int)$params->get('auto_play',1);?>,
		boxCols: <?php echo (int)$params->get('boxCols',8);?>, // For box animations
        boxRows: <?php echo (int)$params->get('boxRows',4);?>, // For box animations
		afterChange:function(){
			nivoLink = $( this ).find(".nivo-caption .lof-title").find("a");
			if(nivoLink.attr("rel")){
				currentLink = nivoLink.attr("rel");
			}
		}
	});
	$('#lofcs-full3d-<?php echo $prfSlide.$blockid;?>').mouseover(function(){
		if( !$( this ).hasClass("has_overlay") ){
			$(this).append('<div class="lof_overlay" style="">&nbsp;</div>');
			$(this).addClass("has_overlay");
			var overlay = $(this).find(".lof_overlay");
			var lofcs = this;
			$( overlay ).click(function(){
				if( currentLink !="" ){
					window.location = currentLink;
				}
				else{
					nivoLink = $( lofcs ).find(".nivo-caption .lof-title").find("a");
					if(nivoLink.attr("rel")){
						window.location = nivoLink.attr("rel");
					}
				}
			});
		}
	});
});
</script>