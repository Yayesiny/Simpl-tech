<?php
/**
 * $ModDesc
 * 
 * @version		$Id: helper.php $Revision
 * @package		modules
 * @subpackage	$Subpackage
 * @copyright	Copyright (C) May 2010 LandOfCoder.com <@emai:landofcoder@gmail.com>. All rights reserved.
 * @website 	htt://landofcoder.com
 * @license		GNU General Public License version 2
 */
if (!defined('_CAN_LOAD_FILES_')){
    define('_CAN_LOAD_FILES_',1);
}
if( !class_exists('LofImageDataSource', false) ){  
	class LofImageDataSource extends LofDataSourceBase{
	    /**
		 * @var string $__name;
		 *
		 * @access private
		 */
		var $__name = 'product';
        
        
        /**
		 * override method: get list image from articles.
		 */
		function getListByParameters( $params, $pparams ){		   
		    $limit = $params->get("limit_items",5);  
		    $subpath = trim( $params->get( 'image_folder', '' ) );  
            if( empty($subpath) ) { return array(); }
            $tmpPath = str_replace( '\\', '/', $subpath ).'/';
            $path = _PS_ROOT_DIR_.'/'.$tmpPath;
            
            $regex = '/(\.gif)|(.jpg)|(.png)|(.bmp)$/i';
            
            $dk =  opendir ( $path );
            $files = array();
			while ( false !== ($filename = readdir ( $dk )) ) {
				if (preg_match ( $regex, $filename )) {
				    $files[] = $filename;	
				}
			}                       
            
            if( is_array($files) ){
                $where = "";
        		$selectCat = $params->get("image_category","");		
        		if($selectCat != ""){
        			$catArray  = explode(",",$selectCat);
        			if(count($catArray) == 1){
        				$where = " AND cp.`id_category` = ".$catArray[0];
        			}else{
        				$where = " AND cp.`id_category` IN (".$selectCat.")";
        			}	
        		}
        		$catArray       = explode(",",$selectCat);
				if(_PS_VERSION_ <="1.4"){
					$datas	= self::getProductsv13( $where,0,$params->get("limit_items",5),"p.id_product" );
				}else{
					$datas  = self::getProductsv14( $where,0,$params->get("limit_items",5),"p.id_product" );
				}        		
                
                $maxDesc = $params->get( 'des_max_chars',100);
                foreach( $datas as $row ){
                    $row['description']=substr(trim(strip_tags($row['description_short'])),0, $maxDesc);
                    $products[strtolower(trim($row["name"]))] = $row;
                }                
                $tmp = $files;
				$overrideLinks = array();
				if( $tmplinks = $params->get('override_links', '' ) ){
					$tmplinks  = is_array($tmplinks )?$tmplinks :array($tmplinks);
					foreach( $tmplinks as $titem ){
						$link  = explode("@", $titem );	
						if( count($link) > 1 ){
							$overrideLinks[trim(strtolower($link[0]))]=$link[1];
						}
					}
				}
                if(count($files)>1){
                    if( trim($params->get( 'image_ordering', '' )) == 'random' ){ 
    					$rand = (array_rand($files, count($files)));
    					$files = ( array_combine(  $rand , $files  ) );
    				}
                }
                $data = array();
				$key = 0;
                foreach( $tmp as  $file){
                    $item = array();
                    $item["link"] = '';
                    $imgName = preg_replace("/\.(\w{3})$/",'',strtolower(trim($file)));                                                         
                    if( isset($products[$imgName]) ){
						$tmp = $products[$imgName];                        
						$item["name"]         = $tmp["name"];
                        $item["description"]  = $tmp["description"];
                        $item["price"]        = Tools::displayPrice($tmp["price"]);                        
					} else {	
						$item["link"] = '#';
						$item["name"] = $imgName;
						$item["description"]  = "";
                        $item["price"]        = "";                        						
					}
                    
                    if( isset($overrideLinks[strtolower(substr($file,0,strlen($file)-4))]) ){
						$item->link = $overrideLinks[strtolower(substr($file,0,strlen($file)-4))];
					}
                    
                    $item["mainImge"] = $tmpPath.$files[$key];
					$item["thumbImge"]  = $tmpPath.$files[$key];                    
					$item = $this->generateImages( $item, $params );
                    
					$data[] = $item;
					//if( $key>= $limit-1 ){ break; }
					
					$key++;
                }                
                return $data;
            }								    		            
            return array();           
		}                        
        
		/**
        * Get data source: 
        */
    	function getProductsv13($where='', $limiStart=0, $limit=10, $order=''){		
    		global $cookie, $link;
			$id_lang = intval($cookie->id_lang);
		
			$sql = '
			SELECT DISTINCT p.id_product, p.*, pa.`id_product_attribute`, pl.`description`, pl.`description_short`, pl.`available_now`, pl.`available_later`, pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`, pl.`name`, i.`id_image`, il.`legend`, m.`name` AS manufacturer_name, tl.`name` AS tax_name, t.`rate`, cl.`name` AS category_default, DATEDIFF(p.`date_add`, DATE_SUB(NOW(), INTERVAL '.(Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20).' DAY)) > 0 AS new,
				(p.`price` * IF(t.`rate`,((100 + (t.`rate`))/100),1) - IF((DATEDIFF(`reduction_from`, CURDATE()) <= 0 AND DATEDIFF(`reduction_to`, CURDATE()) >=0) OR `reduction_from` = `reduction_to`, IF(`reduction_price` > 0, `reduction_price`, (p.`price` * IF(t.`rate`,((100 + (t.`rate`))/100),1) * `reduction_percent` / 100)),0)) AS orderprice 
			FROM `'._DB_PREFIX_.'category_product` cp
			LEFT JOIN `'._DB_PREFIX_.'product` p ON p.`id_product` = cp.`id_product`
			LEFT JOIN `'._DB_PREFIX_.'product_attribute` pa ON (p.`id_product` = pa.`id_product` AND default_on = 1)
			LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON (p.`id_category_default` = cl.`id_category` AND cl.`id_lang` = '.intval($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product` AND pl.`id_lang` = '.intval($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_product` = p.`id_product` AND i.`cover` = 1)
			LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (i.`id_image` = il.`id_image` AND il.`id_lang` = '.intval($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'tax` t ON t.`id_tax` = p.`id_tax`
			LEFT JOIN `'._DB_PREFIX_.'tax_lang` tl ON (t.`id_tax` = tl.`id_tax` AND tl.`id_lang` = '.intval($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'manufacturer` m ON m.`id_manufacturer` = p.`id_manufacturer`
			WHERE  p.`active` = 1'.$where;		
			$sql .= ' ORDER BY '.$order
			.' LIMIT '.$limiStart;			
			$result = Db::getInstance()->ExecuteS($sql);
			
			return Product::getProductsProperties($id_lang, $result);
    	}
		
        /**
        * Get data source: 
        */
    	function getProductsv14($where='', $limiStart=0, $limit=10, $order=''){		
    		global $cookie, $link;
        	$id_lang = intval($cookie->id_lang);
						
			$sql = '
			SELECT DISTINCT p.id_product, p.*, pa.`id_product_attribute`, pl.`description`, pl.`description_short`, pl.`available_now`, pl.`available_later`, pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`, pl.`name`, i.`id_image`, il.`legend`, m.`name` AS manufacturer_name, tl.`name` AS tax_name, t.`rate`, cl.`name` AS category_default, DATEDIFF(p.`date_add`, DATE_SUB(NOW(), INTERVAL '.(Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20).' DAY)) > 0 AS new,
				(p.`price` * IF(t.`rate`,((100 + (t.`rate`))/100),1)) AS orderprice
	
	
			FROM `'._DB_PREFIX_.'category_product` cp
			LEFT JOIN `'._DB_PREFIX_.'product` p ON p.`id_product` = cp.`id_product`
			LEFT JOIN `'._DB_PREFIX_.'product_attribute` pa ON (p.`id_product` = pa.`id_product` AND default_on = 1)
			LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON (p.`id_category_default` = cl.`id_category` AND cl.`id_lang` = '.(int)($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (p.`id_product` = pl.`id_product` AND pl.`id_lang` = '.(int)($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_product` = p.`id_product` AND i.`cover` = 1)
			LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (i.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'tax_rule` tr ON (p.`id_tax_rules_group` = tr.`id_tax_rules_group`
													   AND tr.`id_country` = '.(int)Country::getDefaultCountryId().'
													   AND tr.`id_state` = 0)
			LEFT JOIN `'._DB_PREFIX_.'tax` t ON (t.`id_tax` = tr.`id_tax`)
			LEFT JOIN `'._DB_PREFIX_.'tax_lang` tl ON (t.`id_tax` = tl.`id_tax` AND tl.`id_lang` = '.(int)($id_lang).')
			LEFT JOIN `'._DB_PREFIX_.'manufacturer` m ON m.`id_manufacturer` = p.`id_manufacturer`		
			WHERE  p.`active` = 1'.$where;			
			$sql .= ' ORDER BY '.$order
			.' LIMIT '.$limiStart;	
			
    		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS($sql);		
    		return Product::getProductsProperties($id_lang, $result);
    	}                     
	}
}
?>
