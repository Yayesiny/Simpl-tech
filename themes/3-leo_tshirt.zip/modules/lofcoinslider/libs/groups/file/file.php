<?php
/**
 * $ModDesc
 * 
 * @version		$Id: helper.php $Revision
 * @package		modules
 * @subpackage	$Subpackage
 * @copyright	Copyright (C) May 2010 LandOfCoder.com <@emai:landofcoder@gmail.com>. All rights reserved.
 * @website 	htt://landofcoder.com
 * @license		GNU General Public License version 2
 */
if (!defined('_CAN_LOAD_FILES_')){
    define('_CAN_LOAD_FILES_',1);
}
if( !class_exists('LofFileDataSource', false) ){  
	/**
	 * LofFileDataSource
	 * 
	 * @package prestashop_1.4.0.17
	 * @author Dinh Nghia Tran
	 * @copyright 2011
	 * @version $Id$
	 * @access public
	 */
	class LofFileDataSource extends LofDataSourceBase{
	    /**
		 * @var string $__name;
		 *
		 * @access private
		 */
		var $__name = 'product';
                
        /**
		 * override method: get list file from articles.
		 */
		function getListByParameters( $params, $pparams ){
			global $smarty,$cookie;
            $maxFiles = 12;
			$thumbWidth    = (int)$params->get( 'thumbnail_width', 35 );
			$thumbHeight   = (int)$params->get( 'thumbnail_height', 60 );
			$imageHeight   = (int)$params->get( 'main_height', 300 ) ;
			$imageWidth    = (int)$params->get( 'main_width', 556 ) ;
			$isThumb       = $params->get( 'aurenthumb',1);
            $path = __PS_BASE_URI__;            		              			
			if( $params->get('file_source','folder') =='folder' ){
                $subpath = trim( $params->get( 'file_path', '' ) );
                if( empty($subpath) ) { return array(); }
                $tmpPath = str_replace( '\\', '/', $subpath );
                $path = __PS_BASE_URI__.$tmpPath."/";
			}
			 $attributes = array(
					      'preview'     => ''   ,
					      'path'        => ''   , 
					      'title'       => ''   ,
						  'content'     => ''    ,
					   	  'link' 	    => ''   ,
					  	  'filetype'    => 'image',
                          'target'      => '_self',
                          'pan'         => '0',
                          'imagePos'    => 'left',
                          'desc'        => '',
					  	  'isplay'      => '1'  ,
					  	  'pieces'      => '9'  ,
					  	  'timer'  	    => '10',
					  	  'delay'  	    => '0.1',
					  	  'offset' 	    => '300',
					  	  'distance'    => '30',
					      'transition'  => 'easeInOutBack'); 
						 
			 $output = array();
			 $id_lang = $cookie->id_lang;
			 for( $i=1; $i<=$maxFiles; $i++ ){				
			    $file = $params->get($id_lang."-".$i.'-enable', 0); 				
				if($file){
				    $obj = array();					
					foreach( $attributes as $key=>$value){
						$obj[$key]     =  $params->get($id_lang."-".$i.'-'.$key,$value);
					}                    
					$obj["isplay"]     = $obj["isplay"] != 1 ? "false":"true";
            				
					$obj["path"]       = $path.$obj["path"];
					$obj["mainImge"]   = $path.$obj["preview"];
                    $obj["thumbImge"]  = $obj["mainImge"];
					if($obj["preview"] != ""){						
						$obj = $this->generateImages( $obj, $params );
                        $obj["description"]= $obj["desc"];
                        $obj["name"]       = $obj["title"];				                    
                        									
    					$output[]=$obj;                                   
					}					
				}
			 }
	        //print_r($output);die;
			return $output;		              
		}                
	}
}
?>
