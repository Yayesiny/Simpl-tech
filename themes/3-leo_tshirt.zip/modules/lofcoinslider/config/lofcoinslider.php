<?php
if (!defined('_CAN_LOAD_FILES_'))
	exit;
?>
<link rel="stylesheet" href="<?php echo __PS_BASE_URI__."modules/lofcoinslider/assets/admin/form.css";?>" type="text/css" media="screen" charset="utf-8" />
<link rel="stylesheet" href="<?php echo __PS_BASE_URI__."modules/lofcoinslider/assets/admin/farbtastic/farbtastic.css";?>" type="text/css" media="screen" charset="utf-8" />
<script type="text/javascript" src="<?php echo __PS_BASE_URI__."modules/lofcoinslider/assets/admin/farbtastic/farbtastic.js";?>"></script>
<script type="text/javascript" src="<?php echo __PS_BASE_URI__."modules/lofcoinslider/assets/admin/form.js";?>"></script>
<script type="text/javascript">
  $(document).ready(function() {    
   	$('.it-addrow-block .add').each( function( idx , item ){    	  
        $(item).bind('click',function(e){
			var name        = $(item).attr('id').replace('btna-','');            
            var div         = $('<div class="row"></div>');
            var spantext    = $('<span class="spantext"></span>');
            var span        = $('<span class="remove"></span>');
            var input       = $('<input type="text" name="'+name+'[]" value=""/>');
                     			           
			var parent = $(item).parent().parent();
                        
            div.append(spantext);
            div.append(input);
            div.append(span);
                        
            parent.append(div);
            number = parent.find('input').length;                  
            spantext.html(parent.find('input').length);			
            
			span.bind('click',function(){ 
				if( span.parent().find('input').value ) {
					if( confirm('Are you sure to remove this') ) {
						span.parent().remove(); 
					}
				} else {
					span.parent().remove(); 
				}				
			} );				 			
        });
	});
    
	$('.it-addrow-block .remove').bind('click',function(events){	    
	    parent = $(this).parent();        
		if( parent.find('input').value ) {
			if( confirm('Are you sure to remove this') ) {
				parent.remove();
			}
		}else {
			parent.remove();
		}		
	});
        
    $('#demo').hide();
    var f = $.farbtastic('#picker');  
    var selected;
    $('.colorwell')
      .each(function () { f.linkTo(this); $(this).css('opacity', 0.75); })
      .focus(function() {
        //$('#picker').show();
        if (selected) {
          $(selected).css('opacity', 0.75).removeClass('colorwell-selected');
        }
        f.linkTo(this);
        //p.css('opacity', 1);
        $(selected = this).css('opacity', 1).addClass('colorwell-selected');
      });
	  
	//When page loads...
    $(".tab_content").hide(); //Hide all content
    $("ul.tabs li:first").addClass("active").show(); //Activate first tab
    $(".tab_content:first").show(); //Show first tab content
    
    //On Click Event
    $("ul.tabs li").click(function() {
    
    	$("ul.tabs li").removeClass("active"); //Remove any "active" class
    	$(this).addClass("active"); //Add "active" class to selected tab
    	$(".tab_content").hide(); //Hide all tab content
    
    	var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content        
    	$(activeTab).fadeIn(); //Fade in the active ID content
    	return false;
    });	
	
  });
</script>
<h3><?php echo $this->l('Lof Coin Silder Configuration');?></h3>
<?php 
//register Yes - No Lang
$yesNoLang = array("0"=>$this->l('No'),"1"=>$this->l('Yes'));
$fileLangArr = array(
                    "is_ena"        => $this->l('Is Enabled'),
                    "global_set"    => $this->l("Global Settings"),                    
                    "preview"      => $this->l("Image's Name"),                    
                    "link"          => $this->l("Link"),                    
                    "title"         => $this->l("Title")
                    ); 
?>
<form action="<?php echo $_SERVER['REQUEST_URI'].'&rand='.rand();?>" method="post" id="lofform">
 <input type="submit" name="submit" value="<?php echo $this->l('Update');?>" class="button" />
  <fieldset>
    <legend><img src="../img/admin/contact.gif" /><?php echo $this->l('General Setting'); ?></legend>
    <div class="lof_config_wrrapper clearfix">
      <ul>
        <?php 
            echo $this->_params->selectTag("module_theme",$themes,$this->getParamValue("module_theme",'default'),$this->l('Theme - Layout'),'class="inputbox"', 'class="row" title="'.$this->l('Select a theme').'"');       
            echo $this->_params->selectTag("module_group",$groups,$this->getParamValue("module_group",'file'),$this->l('Select Group'),'class="inputbox select-group"', 'class="row" title="'.$this->l('Select a group').'"');
        ?>
		<li class="row module_group-file">
            <?php 
                echo $this->_params->lofGroupTag($this->l('Group File'),"lof-group",'','class="row"');
                $fileSource = array("folder"=>"A folder in your site","anywhere"=>"Anywhere");
                echo $this->_params->selectTag("file_source",$fileSource,$this->getParamValue("file_source",'one_folder'),$this->l('Get files from'),'class="inputbox select-group"');                                
                echo $this->_params->inputTag("file_path",$this->getParamValue("file_path","modules/lofcoinslider/images"),$this->l('Images Folder Path /)'),'class="text_area"','','class="row file_source-folder"');
                
                $fileOption = array(
                                    "enable"    =>$yesNoLang,                                                                  
                                    );
                $languages = Language::getLanguages();
			?>
			<ul class="tabs">
				<?php                        
					foreach($languages as $lan){
				?>
					<li><a href="#tab<?php echo $lan["id_lang"];?>"><?php echo $lan["name"];?></a></li>
				<?php        
					}
				?>                   
			</ul>
			<div class="tab_container">
				<?php 
				$j = 1;
				foreach($languages as $lan){
				?>
					<div id="tab<?php echo $lan["id_lang"];?>" class="tab_content">
					<?php	               
                for($i=1; $i<=10; $i++){                    
                    $fileValues = array(
												"enable"    =>$this->getParamValue($lan["id_lang"]."-".$i."-enable",0),                                                                                                                   
												"preview"   =>$this->getParamValue($lan["id_lang"]."-".$i."-preview",""),
												"link"      =>$this->getParamValue($lan["id_lang"]."-".$i."-link",""),                                                                                                                    
												"desc"      =>$this->getParamValue($lan["id_lang"]."-".$i."-desc",""),
												"title"     =>$this->getParamValue($lan["id_lang"]."-".$i."-title","")                           
                                       );
					if($fileValues["preview"]==""){
						if($i<=4){
							$fileValues["enable"] = "1";
							switch($i){
								case 1:
									$fileValues["preview"] = "slideshow1.jpg";
									$fileValues["desc"] = "When you buy 2 or more products";
									$fileValues["title"] = "10% off";
									break;
								case 2:
									$fileValues["preview"] = "slideshow2.jpg";
									$fileValues["desc"] = "When you buy 2 or more products";
									$fileValues["title"] = "15% off";
									break;
								case 3:
									$fileValues["preview"] = "slideshow3.jpg";
									$fileValues["desc"] = "When you buy 2 or more products";
									$fileValues["title"] = "10% off";
									break;
								default:
									$fileValues["preview"] = "slideshow4.jpg";
									$fileValues["desc"] = "When you buy 2 or more products";
									$fileValues["title"] = "15% off";
							}					
						}
					}
					echo $this->_params->fileTag($lan["id_lang"]."-".$i,$fileOption,$fileValues, $fileLangArr,$this->l('File '.$i),'class="text_area"','','class="row"');                        
		    }                
					?>	
				</div>
				<?php $j++;?>  
				<?php        
					}
				?>
			</div>
			<?php               
               // echo $this->_params->lofGroupTag($this->l('End Group'),"lof-group");
            ?>
        </li>		
        <li class="row module_group-image">
            <?php 
                echo $this->_params->lofGroupTag($this->l('Group Image'),"lof-group",'','class="row"');
                echo $this->_params->inputTag("image_folder",$this->getParamValue("image_folder",""),$this->l('Images Folder Path (img/)'),'class="text_area"','','class="row"');                
                echo $this->_params->getCategory("image_category",$this->getParamValue("image_category",""),$this->l('Select category'),'style="width: 90%;" class="inputbox"','','class="row"',$this->l('Choose One Category which use for matching name of product with name of image to get description for each image in the list (format: name of image name of product)'),$this->l('All Categories'));
                $imageSortArr = array("name"=>$this->l('Name'),"random"=>$this->l('Random'));
                echo $this->_params->selectTag("image_ordering",$imageSortArr,$this->getParamValue("image_ordering",''),$this->l('Image Sorted By'),'class="inputbox"');
                echo $this->_params->lofOverrideLinksTag($this->getParamValue("override_links"),$this->l('Overriding Link for each image'),$this->l('Add row'),"","",$this->l('with format:Name Of Image@LINK, for example: image-1@http://landofcoder.com'));                                                 
            ?>
        </li>       
        
        <li class="row module_group-product">
            <?php 
               echo $this->_params->lofGroupTag($this->l('Group Product'),"lof-group");               
               $homeSorceArr = array("selectcat"=>$this->l('Select category'),"homefeatured"=>$this->l('Home Featured'),"productids"=>$this->l('Product IDs')); 
               echo $this->_params->selectTag("home_sorce",$homeSorceArr,$this->getParamValue("home_sorce","selectcat"),$this->l('Get Product From'),'class="inputbox select-group"','','class="row"');               
               echo $this->_params->getCategory("category[]",$this->getParamValue("category",""),$this->l('Select category'),'size="10" multiple="multiple" style="width: 90%;" class="inputbox"','','class="row home_sorce-selectcat"','',$this->l('All Categories'));
               
               $arrOder = array('p.date_add'=>$this->l('Date Add'),'p.date_add DESC'=>$this->l('Date Add DESC'),
                                'name'=>$this->l('Name'),'name DESC'=>$this->l('Name DESC'),
                                'quantity'=>$this->l('Quantity'),'quantity DESC'=>$this->l('Quantity DESC'),
                                'p.price'=>$this->l('Price'),'p.price DESC'=>$this->l('Price DESC'));
                              
               echo $this->_params->selectTag("order_by",$arrOder,$this->getParamValue("order_by","p.date_add"),$this->l('Order By'),'class="inputbox select-group"','','class="row home_sorce-selectcat"');
               echo $this->_params->inputTag("limit_items",$this->getParamValue("limit_items","5"),$this->l('Limit items'),'class="text_area"','','class="home_sorce-selectcat"');
               echo $this->_params->inputTag("productids",$this->getParamValue("productids","1,2,3,4,5"),$this->l('Product IDs'),'class="text_area"','','class="home_sorce-productids"');
               echo $this->_params->inputTag("des_max_chars",$this->getParamValue("des_max_chars","100"),$this->l('Description Max Chars'),'class="text_area"','','class="row slider_layout-image-description"');               
               echo $this->_params->radioBooleanTag("shadow", $yesNoLang,$this->getParamValue("shadow",0),$this->l('Enable Border image'),'','class="row"','','');
               echo $this->_params->radioBooleanTag("enable_css3", $yesNoLang,$this->getParamValue("enable_css3",0),$this->l('Enable CSS 3'),'','class="row"','','');               
               echo $this->_params->inputTag("module_height",$this->getParamValue("module_height","338"),$this->l('Module Height'),'class="text_area"','class="row"','');
               echo $this->_params->inputTag("module_width",$this->getParamValue("module_width","980"),$this->l('Module Width'),'class="text_area"','class="row"','');			   
			   echo $this->_params->radioBooleanTag("delCaImg", $yesNoLang,$this->getParamValue("delCaImg",0),$this->l('Delete cache folder'),'','class="row"','',$this->l('select it if you want to delete the image folder cache'));
            ?>                    
      </ul>
    </div>
  </fieldset>
    
  <fieldset>
    <legend><img src="../img/admin/contact.gif" /><?php echo $this->l('Main Slider Setting'); ?></legend>
    <div class="lof_config_wrrapper clearfix">
      <ul>
        <?php 
            echo $this->_params->inputTag("boxCols",$this->getParamValue("boxCols",8),$this->l('Box Columns'),'class="text_area"','class="row"','');
            echo $this->_params->inputTag("boxRows",$this->getParamValue("boxCols",4),$this->l('Box Rows'),'class="text_area"','class="row"','');
            echo $this->_params->inputTag("slices",$this->getParamValue("slices",20),$this->l('Limit Slides'),'class="text_area"','class="row"','');
            echo $this->_params->inputTag("start_item",$this->getParamValue("start_item",0),$this->l('Default Slider Showed'),'class="text_area"','class="row"','');
            echo $this->_params->radioBooleanTag("cre_main_size", $yesNoLang, $this->getParamValue("cre_main_size",1),$this->l('Create Main Image sized'),'class="select-option"','class="row"','',$this->l("You can create a new size or use available size."));
            $mainImgSize = array();
            foreach ($formats as $k=> $format):
                $mainImgSize[$format['name']] = $format['name'].'('.$format['width']."x".$format['height'].')';
            endforeach;            
            echo $this->_params->selectTag("main_img_size",$mainImgSize,$this->getParamValue("main_img_size","thickbox"),$this->l('Main Image Size'),'class="inputbox select-group"','class="row cre_main_size-0"','',$this->l("You can create a new size via Menu <b>Preferences/Image</b>."));
            echo $this->_params->inputTag("main_height",$this->getParamValue("main_height",338),$this->l('Main Image Height'),'class="text_area"','class="row cre_main_size-1"','');
            echo $this->_params->inputTag("main_width",$this->getParamValue("main_width",980),$this->l('Main Image Width'),'class="text_area"','class="row cre_main_size-1"','');
        ?>
      </ul>
    </div>
  </fieldset>
  
  <fieldset>
    <legend><img src="../img/admin/contact.gif" /><?php echo $this->l('Navigation'); ?></legend>
        <div class="lof_config_wrrapper clearfix"><ul>
            <?php 
                echo $this->_params->radioBooleanTag("direction_nav", $yesNoLang, $this->getParamValue("direction_nav",1),$this->l('Enable Direction Navigation'),'','class="row"','','');
                echo $this->_params->radioBooleanTag("direc_nav_hide", $yesNoLang, $this->getParamValue("direc_nav_hide",0),$this->l('Direction Navigation Hide'),'','class="row"','','');  
            ?>                                                 
        </ul></div>    
  </fieldset>
    
  <fieldset>
    <legend><img src="../img/admin/contact.gif" /><?php echo $this->l('Effect Setting'); ?></legend>
    <div class="lof_config_wrrapper clearfix">
      <ul>
        <?php 
            echo $this->_params->radioBooleanTag("preload", $yesNoLang, $this->getParamValue("preload",1),$this->l('Enable Preload'),'','class="row"','','');
            echo $this->_params->inputTag("interval",$this->getParamValue("interval",3000),$this->l('Interval'),'class="text_area"','class="row"','');  
            echo $this->_params->inputTag("duration",$this->getParamValue("duration",500),$this->l('Animation duration'),'class="text_area"','class="row"','');
            $effectArra = array("sliceDown"=>"Slice Down","sliceDownLeft"=>"Slice Down Left","sliceUp"=>"Slice Up"
	            	 ,"sliceUpLeft"=>"Slice Up Left","sliceUpDown"=>"Slice Up Down","sliceUpDownLeft"=>"Slice Up Down Left"
	            	 ,"fold"=>"Fold","fade"=>"Fade","random"=>"Random"
	            	 ,"slideInRight"=>"SlideInRight","slideInLeft"=>"SlideInLeft","boxRandom"=>"BoxRandom"
	            	 ,"boxRain"=>"BoxRain","boxRainReverse"=>"BoxRainReverse","boxRainGrow"=>"BoxRainGrow"                     
	            	 ,"boxRainGrowReverse"=>"BoxRainGrowReverse"
           	);
            echo $this->_params->selectTag("effect",$effectArra,$this->getParamValue("effect","random"),$this->l('Animation Transition'),'class="inputbox"','class="row"','','');                                       
            echo $this->_params->radioBooleanTag("auto_play", $yesNoLang, $this->getParamValue("auto_play",0),$this->l('Manual Advance'),'class="inputbox"','class="row"','','');            
            $openTarget = array("_blank"=>$this->l('New window'),"_parent"=>$this->l('Parent window'));            
            echo $this->_params->selectTag("open_target",$openTarget,$this->getParamValue("open_target","_blank"),$this->l('Click link, Open In'),'class="inputbox"','class="row"','','');
        ?>
      </ul>
      
    </div>
  </fieldset>
  <fieldset>
    <legend><img src="../img/admin/contact.gif" /><?php echo $this->l('Customize Style'); ?></legend>
    <div class="lof_config_wrrapper clearfix"><ul>
        <?php
            $enableCaptionArr = array("0"=>$this->l('No'),"1"=>$this->l('Yes - Use Default Style'),"custom_style"=>$this->l('Yes - Use Custom Style'));
            echo $this->_params->selectTag("enable_caption",$enableCaptionArr,$this->getParamValue("enable_caption",1),$this->l('Enable Caption'),'class="inputbox"','class="row"','','');
            
            $color = $this->getParamValue("caption_bg","#0e1012")?$this->getParamValue("caption_bg","#0e1012"):"#0e1012";
            echo $this->_params->inputTag("caption_bg",$color,$this->l('Caption Background'),'class="text_area colorwell"','class="row"','');
            echo $this->_params->inputTag("caption_opacity",$this->getParamValue("caption_opacity","0.8"),$this->l('Caption Opacity'),'class="text_area"','class="row"','');
            
            $color = $this->getParamValue("caption_fontcolor","#0e1012")?$this->getParamValue("caption_fontcolor","#FFFFFF"):"#FFFFFF";
            echo $this->_params->inputTag("caption_fontcolor",$color,$this->l('Caption Font Color'),'class="text_area colorwell"','class="row"','');
            
            $color = $this->getParamValue("caption_linkcolor","#FFFFFF")?$this->getParamValue("caption_linkcolor","#FFFFFF"):"#FFFFFF";
            echo $this->_params->inputTag("caption_linkcolor",$color,$this->l('Caption Link Color'),'class="text_area colorwell"','class="row"','');
            
            echo $this->_params->radioBooleanTag("show_price", $yesNoLang, $this->getParamValue("show_price",1),$this->l('Show Price'),'class="inputbox"','class="row"','','');
            
            $color = $this->getParamValue("price_color","#FFFFFF")?$this->getParamValue("price_color","#FFFFFF"):"#FFFFFF";            
            echo $this->_params->inputTag("price_color",$color,$this->l('Price Color'),'class="text_area colorwell"','class="row"','');                                   
        ?>                                                                     
        </ul>
        <div id="picker"></div>    
    </div>
    
  </fieldset>  
<br />
  <input type="submit" name="submit" value="<?php echo $this->l('Update');?>" class="button" />
  	<fieldset><legend><img src="../img/admin/comment.gif" alt="" title="" /><?php echo $this->l('Information');?></legend>    	
    	<ul>
    	     <li>+ <a target="_blank" href="http://landofcoder.com/our-porfolios/prestashop/item/53-prestashop-lof-slider-module.html"><?php echo $this->l('Detail Information');?></li>
             <li>+ <a target="_blank" href="http://landofcoder.com/forum/forum.html?id=40"><?php echo $this->l('Forum support');?></a></li>
             <li>+ <a target="_blank" href="http://landofcoder.com/submit-request.html"><?php echo $this->l('Customization/Technical Support Via Email');?>.</a></li>
             <li>+ <a target="_blank" href="http://landofcoder.com/download/guides-docs/docs-guide-prestashop/121-prestashop13x-lofcoinslider-module.html"><?php echo $this->l('UserGuide ');?></a></li>
        </ul>
        <br />
        @copyright: <a href="http://landofcoder.com">LandOfCoder.com</a>
    </fieldset>
</form>
