<?php
/**
 * $ModDesc
 * 
 * @version		$Id: file.php $Revision
 * @package		modules
 * @subpackage	$Subpackage.
 * @copyright	Copyright (C) December 2010 LandOfCoder.com <@emai:landofcoder@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
 */
if (!defined('_CAN_LOAD_FILES_')){
	define('_CAN_LOAD_FILES_',1);
}    
/**
 * lofcoinslider Class
 */	
class lofcoinslider extends Module
{
	/**
	 * @var LofParams $_params
	 *
	 * @access private;
	 */
	private $_params = '';	
	
	/**
	 * @var array $_postErrors;
	 *
	 * @access private;
	 */
	private $_postErrors = array();		
	
	/**
	 * @var string $__tmpl is stored path of the layout-theme;
	 *
	 * @access private 
	 */	
	
   /**
    * Constructor 
    */
	function __construct()
	{
		$this->name = 'lofcoinslider';
		parent::__construct();			
		$this->tab = 'LandOfCoder';				
		$this->version = '1.4';
		$this->displayName = $this->l('Lof CoinSlider Module');
		$this->description = $this->l('Lof CoinSlider Module');
		$this->module_key = "f52f088ddc86480c0e4e572e8309a0e3";
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/params.php' ) && !class_exists("LofParams", false) ){
			if( !defined("LOF_LOAD_LIB_PARAMS") ){				
				require( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/params.php' );
				define("LOF_LOAD_LIB_PARAMS",true);
			}
		}		
		$this->_params = new LofParams( $this->name );		   
	}
  
   /**
    * process installing 
    */
	function install(){		
		if (!parent::install())
			return false;
		if(!$this->registerHook('top'))
			return false;
		if(!$this->registerHook('header'))
			return false;	
		$this->defaultValues();
		return true;
	}
	
	 public function defaultValues(){
		$defaultValues = array();
		$defaultValues[1] = array( 
			"enable"     =>"1",
			"preview"     =>"slideshow1.jpg",	
			"link"      =>"#",                                                                                                                  
			"title"     =>"Donec varius orci a nisl",     
			"desc"      =>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean id elit quam, nec ultrices orci. Aenean non semper magna. Proin a euismod erat. Quisque et auctor elit. Nam vulputate tempor libero a ultricies. Etiam congue dictum ullamcorper ",
		   );		  
		$defaultValues[2] = array(
			"enable"     =>"1",
			"preview"     =>"slideshow2.jpg",
			"link"      =>"#",                                                                                                                    
			"title"     =>"Cras vestibulum pharetra",       
			"desc"      =>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean id elit quam, nec ultrices orci. Aenean non semper magna. Proin a euismod erat. Quisque et auctor elit. Nam vulputate tempor libero a ultricies. Etiam congue dictum ullamcorper ",
		   );
		$defaultValues[3] = array(  
			"enable"     =>"1",
			"preview"     =>"slideshow3.jpg",
			"link"      =>"#",                                                                                                                    
			"title"     =>"Donec varius orci a nisl",   
			"desc"      =>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean id elit quam, nec ultrices orci. Aenean non semper magna. Proin a euismod erat. Quisque et auctor elit. Nam vulputate tempor libero a ultricies. Etiam congue dictum ullamcorper ",
		   );
		$defaultValues[4] = array( 
			"enable"     =>"1",
			"preview"     =>"slideshow4.jpg",
			"type"      =>"none", 
			"link"      =>"#",                                                                                                                    
			"title"     =>"Cras vestibulum pharetra",   
			"desc"      =>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean id elit quam, nec ultrices orci. Aenean non semper magna. Proin a euismod erat. Quisque et auctor elit. Nam vulputate tempor libero a ultricies. Etiam congue dictum ullamcorper ",
		   );
		   
		
		$languages = Language::getLanguages(false);
		foreach($languages as $lan){
			foreach( $defaultValues as $i=>$val){
				Configuration::updateValue($this->name.'_'.$lan["id_lang"]."-".$i."-enable", $val['enable'], true);
				Configuration::updateValue($this->name.'_'.$lan["id_lang"]."-".$i."-preview", $val['preview'], true);
				Configuration::updateValue($this->name.'_'.$lan["id_lang"]."-".$i."-type", $val['type'], true);
				Configuration::updateValue($this->name.'_'.$lan["id_lang"]."-".$i."-link", $val['link'], true);
				Configuration::updateValue($this->name.'_'.$lan["id_lang"]."-".$i."-desc", $val['desc'], true);
				Configuration::updateValue($this->name.'_'.$lan["id_lang"]."-".$i."-title", $val['title'], true);
			}
		}
		Configuration::updateValue($this->name.'_'.'module_theme', 'default', true);
		Configuration::updateValue($this->name.'_'.'module_group', 'file', true);
		Configuration::updateValue($this->name.'_'.'file_source', 'folder', true);
		Configuration::updateValue($this->name.'_'.'file_path', 'modules/lofcoinslider/images', true);
		Configuration::updateValue($this->name.'_'.'module_height', 338, true);
		Configuration::updateValue($this->name.'_'.'module_width', 980, true);
		Configuration::updateValue($this->name.'_'.'delCaImg', 0, true);
		Configuration::updateValue($this->name.'_'.'boxCols', 8, true);
		Configuration::updateValue($this->name.'_'.'boxRows', 8, true);
		Configuration::updateValue($this->name.'_'.'slices', 20, true);
		Configuration::updateValue($this->name.'_'.'start_item', 0, true);
		Configuration::updateValue($this->name.'_'.'cre_main_size', 1, true);
		Configuration::updateValue($this->name.'_'.'main_height', 338, true);
		Configuration::updateValue($this->name.'_'.'main_width', 980, true);
		Configuration::updateValue($this->name.'_'.'direction_nav', 1, true);
		Configuration::updateValue($this->name.'_'.'direc_nav_hide', 0, true);
		Configuration::updateValue($this->name.'_'.'preload', 1, true);
		Configuration::updateValue($this->name.'_'.'interval', 3000, true);
		Configuration::updateValue($this->name.'_'.'duration', 300, true);
		Configuration::updateValue($this->name.'_'.'effect', 'random', true);
		Configuration::updateValue($this->name.'_'.'auto_play', 1, true);
		Configuration::updateValue($this->name.'_'.'enable_caption', 1, true);
		Configuration::updateValue($this->name.'_'.'caption_bg', '#0e1012', true);
		Configuration::updateValue($this->name.'_'.'caption_opacity', 0.8, true);
		Configuration::updateValue($this->name.'_'.'caption_fontcolor', '#FFF', true);
		Configuration::updateValue($this->name.'_'.'caption_linkcolor','#FFF', true);
		Configuration::updateValue($this->name.'_'.'show_price', 0, true);
		Configuration::updateValue($this->name.'_'.'price_color', '#FFF', true);
	}
	
	/*
	 * register hook right comlumn to display slide in right column
	 */
	function hookrightColumn($params)
	{		
		return $this->processHook( $params,"rightColumn");
	}
	
	/*
	 * register hook left comlumn to display slide in left column
	 */
	function hookleftColumn($params)
	{		
		return $this->processHook( $params,"leftColumn");
	}
	
	function hooktop($params)
	{		
		return $this->processHook( $params,"top");
	}
	
	function hookfooter($params)
	{		
		return $this->processHook( $params,"footer");
	}
	
	function hookcontenttop($params)
	{ 		
		return $this->processHook( $params,"contenttop");
	}
	
	
	function hookHeader($params)
	{ 
		//removed by romeo tran in version 1.0.1
		//return $this->processHook( $params,"contenttop");        		        
		//added by romeo tran
		global $smarty; 		if($smarty->tpl_vars["page_name"]->value != "index") return;
		if(_PS_VERSION_ <="1.4"){							
			$header = '<link type="text/css" rel="stylesheet" href="'.($this->_path).'tmpl/'. $this->getParamValue('module_theme','default').'/assets/style.css'.'" />
			           <script type="text/javascript" src="'.($this->_path).'assets/script.js'.'"></script>';			
			return $header;			
		}elseif(_PS_VERSION_ < "1.5"){				
			Tools::addCSS(($this->_path).'tmpl/'. $this->getParamValue('module_theme','default').'/assets/style.css', 'all');
			Tools::addJS(($this->_path).'assets/script.js');
		}else{
			$this->context->controller->addCSS(($this->_path).'tmpl/'. $this->getParamValue('module_theme','default').'/assets/style.css', 'all');
			$this->context->controller->addJS(($this->_path).'assets/script.js');
		}  						
	}
  	
	function hooklofTop($params){
		return $this->processHook( $params,"lofTop");
	}
		
	function hookHome($params)
	{
		return $this->processHook( $params,"home");
	}
    
    function hooklofcoinslider1($params){
		return $this->processHook( $params,"lofcoinslider1");
	}
    
    function hooklofcoinslider2($params){
		return $this->processHook( $params,"lofcoinslider2");
	}
    
    function hooklofcoinslider3($params){
		return $this->processHook( $params,"lofcoinslider3");
	}
    
    function hooklofcoinslider4($params){
		return $this->processHook( $params,"lofcoinslider4");
	}
	
	/**
    * Proccess module by hook
    * $pparams: param of module
    * $pos: position call
    */
	function processHook($pparams, $pos="home"){
		global $smarty;                  
		//load param
		if($smarty->tpl_vars["page_name"]->value != "index") return;
		$params = $this->_params;
		$site_url = Tools::htmlentitiesutf8('http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__);
		
		if(_PS_VERSION_ <="1.4"){
			// create thumbnail folder	 						
			$thumbPath = _PS_IMG_DIR_.$this->name;
			
			if( !file_exists($thumbPath) ) {
				mkdir( $thumbPath, 0777 );			
			};
			$thumbUrl = $site_url."img/".$this->name;
		}else{			
			// create thumbnail folder	 			
			$thumbPath = _PS_CACHEFS_DIRECTORY_.$this->name;
			if( !file_exists(_PS_CACHEFS_DIRECTORY_) ) {
				mkdir( _PS_CACHEFS_DIRECTORY_, 0777 );  			
			}; 
			if( !file_exists($thumbPath) ) {
				mkdir( $thumbPath, 0777 );			
			};
			$thumbUrl = $site_url."cache/cachefs/".$this->name;			
		}
		
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' ) && !class_exists("LofDataSourceBase", false) ){
			if( !defined("LOF_LOAD_LIB_GROUP") ) {
				require_once( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' );
				define("LOF_LOAD_LIB_GROUP",true);
			}
		}
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/phpthumb/ThumbLib.inc.php' ) && !class_exists('PhpThumbFactory', false)){						
			if( !defined("LOF_LOAD_LIB_PHPTHUMB") ) {
				require( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/phpthumb/ThumbLib.inc.php' );	
				define("LOF_LOAD_LIB_PHPTHUMB",true);
			}			
		}
		$molTheme = $this->getParamValue('module_theme','default');
		$main_width_theme = $params->get("main_width",980);
		if($molTheme == "box"){
			$main_width_theme = (int)$params->get("main_width",980) - 26;
			$params->set( 'main_width_theme',$main_width_theme);			
		}else if($molTheme == "transparent"){
			$main_width_theme = (int)$params->get("main_width",956) - 21;
			$params->set( 'main_width_theme',$main_width_theme);
		}
        $params->set( 'auto_renderthumb',0);      
        // get call object to process getting source
		$source =  	  $params->get( 'module_group', 'file' );        
		$path = dirname(__FILE__).'/libs/groups/'.strtolower($source)."/".strtolower($source).'.php';       				
		if( !file_exists($path) ){
			return array();	
		}
        require_once $path;
        $objectName = "Lof".ucfirst($source)."DataSource";
	 	$object = new $objectName();		
        $object->setThumbPathInfo($thumbPath,$thumbUrl)
               ->setImagesRendered( array( 'mainImage' => array( (int)$params->get( 'main_width', 980 ), (int)$params->get( 'main_height', 338 )) ) );
        $products = $object->getListByParameters( $params, $pparams );		
		if(!$products){
			if($source == "image"){
				return $this->l("You don't input image folder or don't exist any image in your folder");
			}else{
				return $this->l("Don't exist any product.");
			}
		}
		
		$tmp 			= $params->get( 'module_height', 'auto' );
		$moduleHeight   =  ( $tmp=='auto' ) ? 'auto' : (int)$tmp.'px';
		$tmp            = $params->get( 'module_width', 'auto' );
		$moduleWidth    =  ( $tmp=='auto') ? 'auto': (int)$tmp.'px';
		$theme 			= $params->get( 'theme' , 'default');
		$openTarget 	= $params->get( 'open_target', 'parent' );
		$class 			= $params->get( 'navigator_pos', 0 ) ? '':'lof-snleft';
		$blockid        = $this->id;
		$showButtons 	= $params->get('display_button',1);
		$prfSlide       = $pos;		
		$i=0;		
        foreach($products as &$product){
            $product["groupandnum"] = $params->get('module_group','product')."-".$i.$prfSlide.$blockid;
            $product["titleImg"]    = '#lof-container-'.$product["groupandnum"];
            $i++;    
        }	
		
		
		// template asignment variables
		$smarty->assign( array(	
						      'prfSlide'        => $prfSlide,
							  'blockid' 		=> $blockid,	
							  'moduleWidth'     => $moduleWidth,
							  'moduleHeight'	=> $moduleHeight,
							  'main_width_theme'=>$main_width_theme,
							  'params'		    => $params,							  	
							  'products'		=> $products,
                              'group'		    => $params->get('module_group','product'),
                              'target'		    => $params->get('open_target','_blank'),                                							                                
							  'css3Class'		=> $params->get('enable_css3','1') ? ' lof-css3':''
						));
		//$smarty->assign( array('homeSize' => Image::getSize('thickbox')));
		$open_target = $params->get('open_target','_blank');
		$smarty->assign( 'target','$target="'.$open_target.'"');
		// render for content layout of module
		$content = '';
		ob_start();
		 require( dirname(__FILE__).'/initjs.php' );		
	    $content = ob_get_contents();
	    ob_end_clean();
		
	    return $this->display(__FILE__, 'tmpl/'.$params->get("module_theme","default").'/default.tpl').$content;					
	}
	   	   	   	
   /**
    * Get list of sub folder's name 
    */
	public function getFolderList( $path ) {
		$items = array();
		$handle = opendir($path);
		if (! $handle) {
			return $items;
		}
		while (false !== ($file = readdir($handle))) {
			if (is_dir($path . $file))
				$items[$file] = $file;
		}
		unset($items['.'], $items['..'], $items['.svn']);
		
		return $items;
	}
	
   /**
    * Render processing form && process saving data.
    */	
	public function getContent()
	{
		$html = "";
		if (Tools::isSubmit('submit'))
		{
			$this->_postValidation();

			if (!sizeof($this->_postErrors))
			{													
		        $definedConfigs = array(
		          /* general config */
		          'module_theme'      => '',                  
                  'module_group'      => '',
                   //file group                  
                  'file_source'       => '',
                  'file_path'         => '',
                  //image group
                  'image_folder'      => '',
                  'image_category'    => '',
                  'image_ordering'    => '',                                    
                  //product group
		          'home_sorce'        => '',
                  'order_by'          => '',  
                  'des_max_chars'     => '',                  
	              'productids'        => '',                  		          		          		                            		        
		          'shadow'            => '',
		          'enable_css3'       => '',
		          'module_height'     => '',
		          'module_width'      => '',
				  'delCaImg'	      => '',
		          /*Main CoinSlider Setting*/
                  'boxCols'           => '',
                  'boxRows'           => '',
                  'slices'            => '',
                  'start_item'        => '',                                  		                            		          
		          'cre_main_size'     => '',
		          'main_img_size'     => '',
		          'main_height'       => '',
		          'main_width'        => '',
		          /*Navigator Setting */
		          'direction_nav'     => '',
		          'direc_nav_hide'=> '',
		          /*Effect Setting*/
		          'preload'           => '',
		          'layout_style'      => '',
		          'interval'          => '',
		          'duration'          => '',
		          'effect'            => '',
                  'auto_play'         => '',                  
		          'auto_start'        => '',
		          'open_target'       =>'',
				  /*Customize Style*/
		          'enable_caption'    => '',
		          'caption_bg'        => '',
                  'caption_opacity'   => '',                  
                  'caption_fontcolor' => '',
                  'caption_linkcolor' => '',
                  'price_color'       => '',
                  'show_price'        => ''                                           
		        );
                //file group
				$languages = Language::getLanguages(false);
				foreach($languages as $lan){
					for($i=1; $i<=10; $i++){						
						$definedConfigs[$lan["id_lang"]."-".$i."-enable"]    = "";
						if(Tools::getValue($lan["id_lang"]."-".$i."-enable")){                                                            
							$definedConfigs[$lan["id_lang"]."-".$i."-preview"]   = "";
							$definedConfigs[$lan["id_lang"]."-".$i."-link"]      = "";                                                                                                    
							$definedConfigs[$lan["id_lang"]."-".$i."-desc"]      = "";
							$definedConfigs[$lan["id_lang"]."-".$i."-title"]     = "";                         
						}                                                          
					}
				}
                
		        foreach( $definedConfigs as $config => $key ){    
		      		Configuration::updateValue($this->name.'_'.$config, Tools::getValue($config), true);
		    	}
                if(Tools::getValue('category')){
    		        if(in_array("",Tools::getValue('category'))){
    		          $catList = "";
    		        }else{
    		          $catList = implode(",",Tools::getValue('category'));  
    		        }
                    Configuration::updateValue($this->name.'_category', $catList, true);
                }
                                
                $linkArray = Tools::getValue('override_links');
                if($linkArray){
                    foreach ($linkArray as $key => $value) {
                        if (is_null($value) || $value == "") {
                            unset ($linkArray[$key]);
                        }
                    }
                    $override_links = implode(",",$linkArray);
                    Configuration::updateValue($this->name.'_override_links', $override_links, true);
                }
				$delText = '';	
		        if(Tools::getValue('delCaImg')){					
					if(_PS_VERSION_ <="1.4"){						
						$cacheFol = _PS_IMG_DIR_.$this->name;												
					}else{			
						$cacheFol = _PS_CACHEFS_DIRECTORY_.$this->name;							
					}					
					if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' ) && !class_exists("LofDataSourceBase", false) ){
						if( !defined("LOF_LOAD_LIB_GROUP") ) {
							require_once( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' );
							define("LOF_LOAD_LIB_GROUP",true);
						}
					}
					if (LofDataSourceBase::removedir($cacheFol)){
						$delText =  $this->l('. Cache folder has been deleted');
					}else{
						$delText =  $this->l('. Cache folder can\'tdeleted');
					}  
				}
		        $html .= '<div class="conf confirm">'.$this->l('Settings updated').$delText.'</div>';
			}
			else
			{
				foreach ($this->_postErrors AS $err)
				{
					$html .= '<div class="alert error">'.$err.'</div>';
				}
			}
			// reset current values.
			$this->_params = new LofParams( $this->name );	
		}
			
		return $html.$this->_getFormConfig();
	}
	
	/**
	 * Render Configuration From for user making settings.
	 *
	 * @return context
	 */
	private function _getFormConfig(){		
		$html = '';
		 
	    $formats = ImageType::getImagesTypes( 'products' );
	    $themes=$this->getFolderList( dirname(__FILE__)."/tmpl/" );
        $groups=$this->getFolderList( dirname(__FILE__)."/libs/groups/" );

	    ob_start();
	    include_once dirname(__FILE__).'/config/lofcoinslider.php'; 
	    $html .= ob_get_contents();
	    ob_end_clean(); 
		return $html;
	}
    
	/**
     * Process vadiation before saving data 
     */
	private function _postValidation()
	{
		if (!Validate::isCleanHtml(Tools::getValue('module_height')))
			$this->_postErrors[] = $this->l('The module height you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('module_width')))
			$this->_postErrors[] = $this->l('The module width you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('des_max_chars')) || !is_numeric(Tools::getValue('des_max_chars')))
			$this->_postErrors[] = $this->l('The description max chars you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('start_item')) || !is_numeric(Tools::getValue('start_item')))
			$this->_postErrors[] = $this->l('The Default CoinSlider Showed you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('main_height')) || !is_numeric(Tools::getValue('main_height')))
			$this->_postErrors[] = $this->l('The Main Image Height you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('main_width')) || !is_numeric(Tools::getValue('main_width')))
			$this->_postErrors[] = $this->l('The Main Image Width you entered was not allowed, sorry');
        if (!Validate::isCleanHtml(Tools::getValue('boxCols')) || !is_numeric(Tools::getValue('boxCols')))
			$this->_postErrors[] = $this->l('The Box Col you entered was not allowed, sorry');
        if (!Validate::isCleanHtml(Tools::getValue('boxCols')) || !is_numeric(Tools::getValue('boxCols')))
			$this->_postErrors[] = $this->l('The Box Col Width you entered was not allowed, sorry');
        if (!Validate::isCleanHtml(Tools::getValue('boxRows')) || !is_numeric(Tools::getValue('boxRows')))
			$this->_postErrors[] = $this->l('The Box Row you entered was not allowed, sorry');
        if (!Validate::isCleanHtml(Tools::getValue('slices')) || !is_numeric(Tools::getValue('slices')))
			$this->_postErrors[] = $this->l('The Slices you entered was not allowed, sorry');
        if (!Validate::isCleanHtml(Tools::getValue('start_item')) || !is_numeric(Tools::getValue('start_item')))
			$this->_postErrors[] = $this->l('The start item you entered was not allowed, sorry');                   							
	}
	
   /**
    * Get value of parameter following to its name.
    * 
	* @return string is value of parameter.
	*/
	public function getParamValue($name, $default=''){
		return $this->_params->get( $name, $default );	
	}	  	  		
} 