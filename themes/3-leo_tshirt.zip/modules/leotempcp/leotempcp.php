<?php
/**
 * $ModDesc
 * 
 * @version		$Id: file.php $Revision
 * @package		modules
 * @subpackage	$Subpackage.
 * @copyright	Copyright (C) Jan 2012 leotheme.com <@emai:leotheme@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
 */
 
if (!defined('_CAN_LOAD_FILES_'))
	exit;
class Leotempcp extends Module
{

	var $themeInfo = array();
	var $themePrefix = '';
	var $prefix = '';
	var $fonts = array();
	function __construct()
	{
		$this->name = 'leotempcp';
		$this->tab = 'Home';
		$this->version = '1.0';
		
		parent::__construct();
		
		$this->displayName = $this->l('Leo Theme Control Panel');
		$this->description = $this->l('change theme color');
		$this->confirmUninstall = $this->l('Are you sure you want to unistall Theme Skins?');
		
			/* merging addition configuration from current theme */
		$theme_dir = _THEME_NAME_;
		if(  file_exists(_PS_ALL_THEMES_DIR_.$theme_dir."/info/info.php") ){
			require( _PS_ALL_THEMES_DIR_.$theme_dir."/info/info.php" );
		}
		
		$this->themeInfo   = $this->getInfo();
		$this->themePrefix  = _THEME_NAME_;
		$this->prefix = 'leocp_';
		$this->_fonts();
	//	echo '<pre>'.print_r($this->themeInfo,1 );die;	
	}

	
	public function install()
	{
		if (!parent::install()
				OR !$this->registerHook('top')
				OR !$this->registerHook('header')
				OR Configuration::updateValue('DISPLAY_THMSKINSBLACK', 1) == false

			)
			return false;
		$this->_installConfig();
		return true;
	}
	
	private function _fonts(){
		$this->fonts = array(
			'Verdana, Geneva, sans-serif' => $this->l('Verdana'),
			'Georgia, "Times New Roman", Times, serif' => $this->l('Georgia'),
			'Arial, Helvetica, sans-serif' => $this->l('Arial'),
			'Impact, Arial, Helvetica, sans-serif' => $this->l('Impact'),
			'Tahoma, Geneva, sans-serif' => $this->l('Tahoma'),
			'"Trebuchet MS", Arial, Helvetica, sans-serif' => $this->l('Trebuchet MS'),
			'"Arial Black", Gadget, sans-serif' => $this->l('Arial Black'),
			'Times, "Times New Roman", serif' => $this->l('Times'),
			'"Palatino Linotype", "Book Antiqua", Palatino, serif' => $this->l('Palatino Linotype'),
			'"Lucida Sans Unicode", "Lucida Grande", sans-serif' => $this->l('Lucida Sans Unicode'),
			'"MS Serif", "New York", serif' => $this->l('MS Serif'),
			'"Comic Sans MS", cursive' => $this->l('Comic Sans MS'),
			'"Courier New", Courier, monospace' => $this->l('Courier New'),
			'"Lucida Console", Monaco, monospace' => $this->l('Lucida Console')
		);
	}
	private function _installConfig(){
		$configs = array(
			'font_type1' => 'standard',
			'standard_font1' => 'Arial, Helvetica, sans-serif',
			'google_link1' => '',
			'google_font1' => '',
			'selector1' => '',
			
			'font_type2' => 'standard',
			'standard_font2' => 'Arial, Helvetica, sans-serif',
			'google_link2' => '',
			'google_font2' => '',
			'selector2' => '',
			
			'font_type3' => 'standard',
			'standard_font3' => 'Arial, Helvetica, sans-serif',
			'google_link3' => '',
			'google_font3' => '',
			'selector3' => '',
			
			'font_type4' => 'standard',
			'standard_font4' => 'Arial, Helvetica, sans-serif',
			'google_link4' => '',
			'google_font4' => '',
			'selector4' => '',
		);
		
		foreach($configs as $key => $val){
			Configuration::updateValue($this->prefix.$key, $val, true);
		}
		return true;
	}
	
	function getContent()
	{
		$this->_html = '<h2>'.$this->displayName.'</h2>';
		if (isset($_POST['submitUpdate']))
		{	
			$variables = array(
				'font_type1' => '',
				'standard_font1' => '',
				'google_link1' => '',
				'google_font1' => '',
				'selector1' => '',
				
				'font_type2' => '',
				'standard_font2' => '',
				'google_link2' => '',
				'google_font2' => '',
				'selector2' => '',
				
				'font_type3' => '',
				'standard_font3' => '',
				'google_link3' => '',
				'google_font3' => '',
				'selector3' => '',
				
				'font_type4' => '',
				'standard_font4' => '',
				'google_link4' => '',
				'google_font4' => '',
				'selector4' => '',
			);
			foreach($variables as $k=>$v){
				Configuration::updateValue($this->prefix.$k, Tools::getValue($k));
			}
			$leoskin = (Tools::getValue('leoskin')); 
			Configuration::updateValue('leoskin', $leoskin);
			$leopntool = (Tools::getValue('leopntool')); 
			Configuration::updateValue('leopntool', $leopntool);
			$leorespon = (Tools::getValue('leorespon')); 
			Configuration::updateValue('leorespon', $leorespon);
			
		 	$templatewidth = (Tools::getValue('templatewidth')); 
			Configuration::updateValue('templatewidth', $templatewidth);
			$leolayout = (Tools::getValue('leolayout')); 
			Configuration::updateValue('leolayout', $leolayout);
			
			LeoThemeInfo::onUpdateConfig();
			$forbidden = array('submitUpdate');
			
			foreach ($_POST AS $key => $value){
				if (!Validate::isCleanHtml($_POST[$key]))
				{
					$this->_html .= $this->displayError($this->l('Invalid html field, javascript is forbidden'));
					$this->_displayForm();
					return $this->_html;
				}
			}
		}

		$this->_displayForm();
		
		return $this->_html;
	}

	private function _displayForm()
	{
		global $cookie;
		
		if( empty($this->themeInfo) ){
			$this->_html .= '	<fieldset style="width: 900px;"><legend><img src="'.$this->_path.'logo.gif" alt="" title="" /> '.$this->displayName.'</legend>'.
				$this->l("The Theme Configuration is not avariable, because may be you forgot set a theme from LeoTheme.Com as default theme of front-office, Please try to check again")
			.'</fieldset';
			
			return ;
		}
		
		$skins = $this->themeInfo["skins"];
		$dskins = Configuration::get('leoskin');
		$dlayout = Configuration::get('leolayout');
		$layouts = array( "-lcr" => $this->l("Content-Right") ,
						  "-rcl" => $this->l("Right-content"));
		$this->_html .= '<br />
		<form method="post" action="'.$_SERVER['REQUEST_URI'].'" enctype="multipart/form-data">
			<fieldset>
				<legend><img src="'.$this->_path.'logo.gif" alt="" title="" /> '.$this->displayName.'</legend>
				<h4>'. $this->l( "Configuration For <i>" . _THEME_NAME_ . "</i> Theme " ) .'</h4>
				<script type="text/javascript" src="'.__PS_BASE_URI__.'modules/'.$this->name.'/assets/admin/form.js"></script>
				<link rel="stylesheet" href="'.__PS_BASE_URI__.'modules/'.$this->name.'/assets/admin/jquery-ui.css" type="text/css" media="screen" charset="utf-8" />
				<div class="lof_config_wrrapper clearfix ui-tabs ui-widget ui-widget-content ui-corner-all" id="lof-pdf-tab">
					<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
						<li class="ui-state-default ui-corner-top ui-tabs-selected ui-state-active"><a class="lof-tab" href="javascript:void(0)" rel="#top"><span>'.$this->l("Basic settings").'</span></a></li>
						<li class="ui-state-default ui-corner-top"><a class="lof-tab" href="javascript:void(0)" rel="#left"><span>'.$this->l("Fonts").'</span></a></li>
					</ul>
					<div id="top" class="ui-tabs-panel ui-widget-content ui-corner-bottom">
						<label>'.$this->l('Template Width').'</label>
						<div class="margin-form">
							<input name="templatewidth" value="'.(Tools::getValue('templatewidth', "980px") ).'"/>
							<div class="clear clr"></div><sub>'.$this->l("Set Template Width in number(px) or number(%), for example 980px, 99% ").'</sub>
						</div>
						<label>'.$this->l('Default Skin').'</label>
						<div class="margin-form">
							
							<select name="leoskin">';
								foreach( $skins as $skin ){
									$this->_html .= '<option '.($skin==$dskins?'selected="selected"':"").' value="'.$skin.'">'.$this->l($skin).'</option>';
								}
							$this->_html .=	'</select>
						</div>	
						
						<label>'.$this->l('Layout Direction').'</label>
						<div class="margin-form">
							<select name="leolayout">';
								foreach( $layouts as $key=>$layout ){
									$this->_html .= '<option '.($key==$dlayout?'selected="selected"':"").' value="'.$key.'">'.$this->l($layout).'</option>';
								}
							$this->_html .=	'</select>
						</div>	
						
						<label>'.$this->l('Panel Toool').'</label>	
						<div class="margin-form">
							<input type="radio" name="leopntool" id="leopntool_on" value="1" '.(Tools::getValue('leopntool', Configuration::get('leopntool')) ? 'checked="checked" ' : '').'/>
							<label class="t" for="leopntool_on"> <img src="../img/admin/enabled.gif" /></label>
							<input type="radio" name="leopntool" id="leopntool_off" value="0" '.(!Tools::getValue('leopntool', Configuration::get('leopntool')) ? 'checked="checked" ' : '').'/>
							<label class="t" for="leopntool_off"> <img src="../img/admin/disabled.gif" /></label>
						</div>	
						<label>'.$this->l('Responsive feature').'</label>	
						<div class="margin-form">
							<input type="radio" name="leorespon" id="leorespon_on" value="1" '.(Tools::getValue('leorespon', Configuration::get('leorespon')) ? 'checked="checked" ' : '').'/>
							<label class="t" for="leorespon_on"> <img src="../img/admin/enabled.gif" /></label>
							<input type="radio" name="leorespon" id="leorespon_off" value="0" '.(!Tools::getValue('leorespon', Configuration::get('leorespon')) ? 'checked="checked" ' : '').'/>
							<label class="t" for="leorespon_off"> <img src="../img/admin/disabled.gif" /></label>
						</div>	
						';
					$this->_html = LeoThemeInfo::onRenderForm( $this->_html, $this );	
					$this->_html .= '<div class="clear pspace"></div>
						<div class="margin-form clear"><input type="submit" name="submitUpdate" value="'.$this->l('    SAVE    ').'" class="button" /></div>
					</div>
					<div id="left" class="ui-tabs-panel ui-widget-content ui-corner-bottom"  style="display:none;" >
						<label>'.$this->l('Google Font Directory').'</label>
						<div class="margin-form">
							<a href="http://code.google.com/webfonts" target="_blank" title="'.$this->l('Google Fonts').'">'.$this->l('Click here').'</a>
						</div>
						<div class="clear"></div>
						<div class="separation"></div>
						<label>'.$this->l('Body - font').'</label>
						<div class="margin-form">
							<select name="font_type1" id="font_type1" class="font_type">
								<option value="standard"'.(Configuration::get($this->prefix.'font_type1') == 'standard' ? ' selected="selected"' : '').'>'.$this->l('Standard').'</option>
								<option value="google"'.(Configuration::get($this->prefix.'font_type1') == 'google' ? ' selected="selected"' : '').'>'.$this->l('Google Fonts').'</option>
							</select>';
						$this->_html .= ' 
							<select name="standard_font1" class="font_type1 font_type1_standard">';
								foreach($this->fonts as $key=>$row){
									$this->_html .= '<option value="'.$key.'"'.($key == Configuration::get($this->prefix.'standard_font1') ? ' selected="selected"' : '').'>'.$row.'</option>';
								}
					$this->_html .= '
							</select>
						</div>
						<div class="clear"></div>
						<div class="font_type1 font_type1_google">
							<label>'.$this->l('Font url:').'</label>
							<div class="margin-form">
								<input type="text" name="google_link1" value="'.Configuration::get($this->prefix.'google_link1').'" size="40"/>
								<p>'.$this->l('Example: http://fonts.googleapis.com/css?family=Petit+Formal+Script').'</p>
							</div>
							<label>'.$this->l('Font family:').'</label>
							<div class="margin-form">
								<input type="text" name="google_font1" value="'.Configuration::get($this->prefix.'google_font1').'" size="40"/>
								<p>'.$this->l('Example: Petit Formal Script').'</p>
							</div>
						</div>
						<div class="clear"></div>
						<label>'.$this->l('Body - selectors').'</label>
						<div class="margin-form">
							<textarea cols="50" rows="5" name="selector1">'.Configuration::get($this->prefix.'selector1').'</textarea>
							<p>'.$this->l('Example: h1,h2,#lof-title h3').'</p>
						</div>
						<div class="clear"></div>
						<div class="separation"></div>
						<label>'.$this->l('Headers - font').'</label>
						<div class="margin-form">
							<select name="font_type2" id="font_type2" class="font_type">
								<option value="standard"'.(Configuration::get($this->prefix.'font_type2') == 'standard' ? ' selected="selected"' : '').'>'.$this->l('Standard').'</option>
								<option value="google"'.(Configuration::get($this->prefix.'font_type2') == 'google' ? ' selected="selected"' : '').'>'.$this->l('Google Fonts').'</option>
							</select>';
							$this->_html .= ' 
							<select name="standard_font2" class="font_type2 font_type2_standard">';
								foreach($this->fonts as $key=>$row){
									$this->_html .= '<option value="'.$key.'"'.($key == Configuration::get($this->prefix.'standard_font2') ? ' selected="selected"' : '').'>'.$row.'</option>';
								}
					$this->_html .= '
							</select>
						</div>
						<div class="clear"></div>
						<div class="font_type2 font_type2_google">
							<label>'.$this->l('Font url:').'</label>
							<div class="margin-form">
								<input type="text" name="google_link2" value="'.Configuration::get($this->prefix.'google_link2').'" size="40"/>
								<p>'.$this->l('Example: http://fonts.googleapis.com/css?family=Petit+Formal+Script').'</p>
							</div>
							<label>'.$this->l('Font family:').'</label>
							<div class="margin-form">
								<input type="text" name="google_font2" value="'.Configuration::get($this->prefix.'google_font2').'" size="40"/>
								<p>'.$this->l('Example: Petit Formal Script').'</p>
							</div>
						</div>
						<div class="clear"></div>
						<label>'.$this->l('Headers - selectors:').'</label>
						<div class="margin-form">
							<textarea cols="50" rows="5" name="selector2">'.Configuration::get($this->prefix.'selector2').'</textarea>
							<p>'.$this->l('Example: h1,h2,#lof-title h3').'</p>
						</div>
						<div class="clear"></div>
						<div class="separation"></div>
						<label>'.$this->l('Other I - font:').'</label>
						<div class="margin-form">
							<select name="font_type3" id="font_type3" class="font_type">
								<option value="standard"'.(Configuration::get($this->prefix.'font_type3') == 'standard' ? ' selected="selected"' : '').'>'.$this->l('Standard').'</option>
								<option value="google"'.(Configuration::get($this->prefix.'font_type3') == 'google' ? ' selected="selected"' : '').'>'.$this->l('Google Fonts').'</option>
							</select>';
							$this->_html .= ' 
							<select name="standard_font3" class="font_type3 font_type3_standard">';
								foreach($this->fonts as $key=>$row){
									$this->_html .= '<option value="'.$key.'"'.($key == Configuration::get($this->prefix.'standard_font3') ? ' selected="selected"' : '').'>'.$row.'</option>';
								}
					$this->_html .= '
							</select>
						</div>
						<div class="clear"></div>
						<div class="font_type3 font_type3_google">
							<label>'.$this->l('Font url:').'</label>
							<div class="margin-form">
								<input type="text" name="google_link3" value="'.Configuration::get($this->prefix.'google_link3').'" size="40"/>
								<p>'.$this->l('Example: http://fonts.googleapis.com/css?family=Petit+Formal+Script').'</p>
							</div>
							<label>'.$this->l('Font family:').'</label>
							<div class="margin-form">
								<input type="text" name="google_font3" value="'.Configuration::get($this->prefix.'google_font3').'" size="40"/>
								<p>'.$this->l('Example: Petit Formal Script').'</p>
							</div>
						</div>
						<div class="clear"></div>
						<label>'.$this->l('Other I - selectors:').'</label>
						<div class="margin-form">
							<textarea cols="50" rows="5" name="selector3">'.Configuration::get($this->prefix.'selector3').'</textarea>
							<p>'.$this->l('Example: h1,h2,#lof-title h3').'</p>
						</div>
						<div class="separation"></div>
						<label>'.$this->l('Other II - font:').'</label>
						<div class="margin-form">
							<select name="font_type4" id="font_type4" class="font_type">
								<option value="standard"'.(Configuration::get($this->prefix.'font_type4') == 'standard' ? ' selected="selected"' : '').'>'.$this->l('Standard').'</option>
								<option value="google"'.(Configuration::get($this->prefix.'font_type4') == 'google' ? ' selected="selected"' : '').'>'.$this->l('Google Fonts').'</option>
							</select>';
							$this->_html .= ' 
							<select name="standard_font4" class="font_type4 font_type4_standard">';
								foreach($this->fonts as $key=>$row){
									$this->_html .= '<option value="'.$key.'"'.($key == Configuration::get($this->prefix.'standard_font4') ? ' selected="selected"' : '').'>'.$row.'</option>';
								}
					$this->_html .= '
							</select>
						</div>
						<div class="clear"></div>
						<div class="font_type4 font_type4_google">
							<label>'.$this->l('Font url:').'</label>
							<div class="margin-form">
								<input type="text" name="google_link4" value="'.Configuration::get($this->prefix.'google_link4').'" size="40"/>
								<p>'.$this->l('Example: http://fonts.googleapis.com/css?family=Petit+Formal+Script').'</p>
							</div>
							<label>'.$this->l('Font family:').'</label>
							<div class="margin-form">
								<input type="text" name="google_font4" value="'.Configuration::get($this->prefix.'google_font4').'" size="40"/>
								<p>'.$this->l('Example: Petit Formal Script').'</p>
							</div>
						</div>
						<div class="clear "></div>
						<label>'.$this->l('Other I - selectors:').'</label>
						<div class="margin-form">
							<textarea cols="50" rows="5" name="selector4">'.Configuration::get($this->prefix.'selector4').'</textarea>
							<p>'.$this->l('Example: h1,h2,#lof-title h3').'</p>
						</div>
						
						<div class="clear space"></div>
						<div class="margin-form clear"><input type="submit" name="submitUpdate" value="'.$this->l('    SAVE    ').'" class="button" /></div>
					</div>
				</div>
			</fieldset>
		</form>';
	}

	public function getInfo(){
		
		$theme_dir = _THEME_NAME_;
		$info = simplexml_load_file( _PS_ALL_THEMES_DIR_.$theme_dir.'/config.xml' );
		if( !$info || !isset($info->name)|| !isset($info->positions) ){
			return null;
		}
		$p = (array)$info->positions;
		$output = array("skins"=>"","positions"=>$p["position"],"name"=>(string)$info->name );
		if( isset($info->skins) ){
			$tmp =  (array)$info->skins;
			$output["skins"] = $tmp["skin"];
		}
		
	
		$output = LeoThemeInfo::onGetInfo( $output );
		return $output;
	}
	
	function hooktop($params)
	{
		global $cookie, $smarty;
		
		if( $this->themeInfo ){
			$skin = Configuration::get('leoskin');
			$bgpattern = Configuration::get('leobgpattern');
			$layout = Configuration::get('leolayout');
			if(!$layout)
				$layout = '-lcr';
			
			$paneltool =  Tools::getValue('leopntool', Configuration::get('leopntool'));
			/* if enable user custom setting, the theme will use those configuration*/
			if( $paneltool ){
				//echo $_GET['bgpattern']; die;
				$vars = array("skin"=>$skin,"layout"=>$layout,"bgpattern"=>$bgpattern);
				if( isset($_GET["usercustom"]) && strtolower( $_GET['usercustom'] ) == "apply" ){
					foreach( $vars as $key => $val ){
						if( isset($_GET[$key]) ){  
							$cookie->__set( "leou_".$key, $_GET[$key] );
							$val =  $_GET[$key];
						}
					}
					Tools::redirect( "index.php" );
				}
				if( isset($_GET["leoaction"]) && $_GET["leoaction"] == "reset" ){
					foreach( $vars as $key => $val ){
						$cookie->__set("leou_".$key, Configuration::get("leo"+$key));
					}
					Tools::redirect( "index.php" );	
				} 
				//echo "<pre>".print_r($cookie,1); die;
				foreach( $vars as $key => $val ){
					if( $cookie->__get(  "leou_".$key ) ){
						$$key = $cookie->__get(  "leou_".$key );	
					}else {
						$$key = $val;
					}
				}
			}
			//echo $cookie->__get(  "leou_bgpattern" ); die;
			$ps = array(		  	
				'LEO_SKIN_DEFAULT' => $skin,
				'this_path' 	   => $this->_path,
				'LEO_PANELTOOL'	   => $paneltool,
				'LEO_THEMEINFO'    => $this->themeInfo,
				'LEO_THEMENAME'	   => _THEME_NAME_,
				'LEO_LAYOUT_DIRECTION' => $layout,
				'LEO_PATTERN' => $bgpattern.'.png',
				'LEO_BGPATTERN' => $bgpattern,
				'HOOK_SLIDESHOW' => ''
			);
			
			//$ps = LeoThemeInfo::onProcessHookTop( $ps );
			
			$smarty->assign( $ps );
			
		
		}
		
		return false;
	}		
	
	function hookHeader(){
		$leorespon =  Tools::getValue('leorespon', Configuration::get('leorespon'));
		$amounts = 4; 
		$output = '';
		for($i = 1; $i <= $amounts; $i++){
			$font_type = Configuration::get($this->prefix.'font_type'.$i);
			if(Configuration::get($this->prefix.'selector'.$i)){
				if($font_type == 'standard'){
					$output .= '<style type="text/css">
						'.Configuration::get($this->prefix.'selector'.$i).'{font-family: ' . Configuration::get($this->prefix.'standard_font'.$i) . '; }
					</style>';
				}elseif($font_type == 'google') {
					$font_link = Configuration::get($this->prefix.'google_link'.$i);
					$font_family =Configuration::get($this->prefix.'google_font'.$i);
					$output .= '<link rel="stylesheet" type="text/css" href="'.$font_link.'" />';
					$output .= '<style type="text/css">
						'.Configuration::get($this->prefix.'selector'.$i).'{font-family: \''.$font_family. '\'; }
					</style>';
				}
			}
		}
		if( $leorespon ){
			$output .= '<link rel="stylesheet" type="text/css" href="'.__PS_BASE_URI__.'themes/'._THEME_NAME_.'/css/responsive.css" />';
		}
		$output .= ' <style type="text/css">
			#page .leo-wrapper{ max-width:'.Tools::getValue('templatewidth', Configuration::get('templatewidth',"980px")).'}
			</style>';
		return $output;		
	}
}
