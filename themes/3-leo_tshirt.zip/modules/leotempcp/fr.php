<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{thmskins}prestashop>thmskins_f0829f0a745a34bff7565504856489ca'] = 'Changer la couleur de votre theme';
$_MODULE['<{thmskins}prestashop>thmskins_e90dfb84e30edf611e326eeb04d680de'] = 'Noir';
$_MODULE['<{thmskins}prestashop>thmskins_25a81701fbfa4a1efdf660a950c1d006'] = 'Blanc';
$_MODULE['<{thmskins}prestashop>thmskins_ee38e4d5dd68c4e440825018d549cb47'] = 'Rouge';
$_MODULE['<{thmskins}prestashop>thmskins_9594eec95be70e7b1710f730fdda33d9'] = 'Bleu';
$_MODULE['<{thmskins}prestashop>thmskins_f5cf47ab06d0d98b0d16d10c82d87953'] = 'Mise à Jour';
