/*
 * 	Easy Slider 1.5 - jQuery plugin
 *	written by Alen Grakalic	
 *	http://cssglobe.com/post/4004/easy-slider-15-the-easiest-jquery-plugin-for-sliding
 *
 *	Copyright (c) 2009 Alen Grakalic (http://cssglobe.com)
 *	Dual licensed under the MIT (MIT-LICENSE.txt)
 *	and GPL (GPL-LICENSE.txt) licenses.
 *
 *	Built for jQuery library
 *	http://jquery.com
 *
 */
 
/*
 *	markup example for $("#slider").easySlider();
 *	
 * 	<div id="slider">
 *		<ul>
 *			<li><img src="images/01.jpg" alt="" /></li>
 *			<li><img src="images/02.jpg" alt="" /></li>
 *			<li><img src="images/03.jpg" alt="" /></li>
 *			<li><img src="images/04.jpg" alt="" /></li>
 *			<li><img src="images/05.jpg" alt="" /></li>
 *		</ul>
 *	</div>
 *
 */

(function($) {
    $.fn.loftabs = function( options ){
        	// default configuration properties
		var defaults = {
            positionActive: 0,
            moduleId: "",            
			continuous:		false
		}; 
		
		var options = $.extend(defaults, options);  
        
        this.each( function(){
            //var container = this;
            //alert(".lof-tabnews-content-"+options.moduleId+" .lof-content-tab-"+options.moduleId);
            var tabs = $( ".tabs-panel-"+options.moduleId+" li a", this);
            var containers  =  $( ".lof-tabnews-content .lof-content-tab-"+options.moduleId, this);     
            var tabwrapper = $( ".lof-tabnews-content", this)
            tabs.eq(options.positionActive).addClass("active");
			currentTab = tabs.eq(options.positionActive).attr('id');
			lofmarginleft[currentTab] = 0;
			lofwidth[currentTab] = 0;
            containers.hide().eq(options.positionActive).show();
            tabs.click( function(){
				currentTab = $(this).attr('id');
                 tabs.removeClass("active");
                 var current = $( $(this).addClass("active").attr("href") );
                    containers.not(current).hide();
				var value = $(this).attr('rel');
				var class_div = $(this).attr('id');
				if(value != 'lof'){
					getData(value, class_div);
					$(this).attr('rel','lof');
				}
                current.show(); 
              return false;
            } );
        } );
		
		function getData(value, class_div){
			$("."+class_div).html('<div class="lofload" style="height:'+$("." + class_div).parent().parent().parent().height()+'px;"></div>');
			$.ajax({
				type: "POST",
				url: ajaxUrl,
				data: "data="+value+"&task=getFirstData",
				success: function(data){
					$("."+class_div).html(data);
				}
			});
		}
    };
    
	$.fn.lofeasySliderTabs = function(options){
	  
		// default configuration properties
		var defaults = {			
			prevId: 		'prevBtn',
			prevText: 		'Previous',
			nextId: 		'nextBtn',	
			nextText: 		'Next',
			controlsShow:	true,
			controlsBefore:	'',
			controlsAfter:	'',	
			controlsFade:	true,
            widthPage:      550,
			firstId: 		'firstBtn',
			firstText: 		'First',
			firstShow:		false,
			lastId: 		'lastBtn',	
			lastText: 		'Last',
			lastShow:		false,				
			vertical:		false,
			speed: 			200,
			auto:			false,
			pause:			1000,
			continuous:		false
		}; 
		
		var options = $.extend(defaults, options);  
				
		this.each(function(i) {  
			var obj = $(this); 		
         //    alert( obj.html() );		
			obj.find('ul li').css({'width':obj.width()});
			var s = $("li", obj).length;
            
			//var w = $("li", obj).width(); 
            //alert(s);
            var w = obj.width();
			lofwidth[currentTab] = w;
			//var h = $("li", obj).height(); 
			//obj.width(w); 
			//alert(obj.width())
			//obj.height(h); 
			//obj.css("overflow","hidden");
			var ts = s-1;
			var t = 0;
			$("ul", obj).css('width',(s*w)+(s*10));			
			if(!options.vertical) $("li", obj).css('float','left');
			
			if(options.controlsShow){
				var html = options.controlsBefore;
				if(options.firstShow) html += '<span id="'+ options.firstId +'"><a href=\"javascript:void(0);\">'+ options.firstText +'</a></span>';
				html += ' <span id="'+ options.prevId +'"><a href=\"javascript:void(0);\">'+ options.prevText +'</a></span>';
				html += ' <span id="'+ options.nextId +'"><a href=\"javascript:void(0);\">'+ options.nextText +'</a></span>';
				if(options.lastShow) html += ' <span id="'+ options.lastId +'"><a href=\"javascript:void(0);\">'+ options.lastText +'</a></span>';
				html += options.controlsAfter;						
				$(obj).after(html);										
			};
 
			$("#"+options.nextId).click(function(){
				animate("next",true);
				getData(options.nextId);
			});
			$("#"+options.prevId).click(function(){
				animate("prev",true);
				getData(options.prevId);
			});	
			$("#"+options.firstId).click(function(){
				animate("first",true);
			});				
			$("#"+options.lastId).click(function(){
				animate("last",true);				
			});		
			
			function animate(dir,clicked){
				var ot = t;
				var lofw = obj.width();
				lofwidth[currentTab] = lofw;
				
				switch(dir){
					case "next":
						t = (ot>=ts) ? (options.continuous ? 0 : ts) : t+1;						
						break; 
					case "prev":
						t = (t<=0) ? (options.continuous ? ts : 0) : t-1;
						break; 
					case "first":
						t = 0;
						break; 
					case "last":
						t = ts;
						break; 
					default:
						break; 
				};	
				
				var diff = Math.abs(ot-t);
				var speed = diff*options.speed;						
				if(!options.vertical) {
					w = $("ul",obj).find('li').width();
					p = (t*(w)*-1);
					
					lofindex[currentTab] = t;
					lofmarginleft[currentTab] = p;
					//alert(lofmarginleft[currentTab]);
					$("ul",obj).animate(
						{ marginLeft: p }, 
						speed
					);				
				} else {
					p = (t*h*-1);
					$("ul",obj).animate(
						{ marginTop: p }, 
						speed
					);					
				};
				
				if(!options.continuous && options.controlsFade){					
					if(t==ts){
						$("#"+options.nextId).hide();
						$("#"+options.lastId).hide();
					} else {
						$("#"+options.nextId).show();
						$("#"+options.lastId).show();					
					};
					if(t==0){
						$("#"+options.prevId).hide();
						$("#"+options.firstId).hide();
					} else {
						$("#"+options.prevId).show();
						$("#"+options.firstId).show();
					};					
				};				
				
				if(clicked) clearTimeout(timeout);
				if(options.auto && dir=="next" && !clicked){;
					timeout = setTimeout(function(){
						getData(options.nextId);
						animate("next",false);
					},diff*options.speed+options.pause);
				};
				
			};
			function getData(id_nav){
				var data = $("#"+id_nav).find('a').attr('rel');
				//var id_page = $("#"+id_nav).find('a').attr('id');
				//var pages = id_page.split("_");
				//var page = parseInt(pages[1]);
				var page = $("#"+id_nav).parent().find("#lofpage-"+data).attr('rel');
				var totalpage = $("#"+id_nav).parent().find('#totalPages-'+data).attr('rel');
				if(id_nav == options.nextId){
					var action = 'next';
					if(page == (parseInt(totalpage) - 1)){
						page = 0;
					}else{
						page = parseInt(page) + 1;
					}
				}else if(id_nav == options.prevId){
					var action = 'prev';
						
					if(parseInt(page) == 0){
						page = parseInt(totalpage) - 1;
					}else{
						page = parseInt(page) - 1;
					}
				}
				//$("#"+id_nav).find('a').attr('id','page_'+page);
				$("#"+id_nav).parent().find("#lofpage-"+data).attr('rel', page);
				
				var id_div = 'lofpage-' + data + '-'+page;
				
				if($("#" + id_div).hasClass('lof_load') || isNaN(page))
					return true;
				$("#" + id_div).html('<div class="lofload" style="height:'+$("#" + id_div).parent().height()+'px;"></div>');
				
				
				$.ajax({
					type: 'POST',
					dataType: 'json',
					url: ajaxUrl,
					data: "data="+data+"&page="+page+"&totalpage="+totalpage+"&action="+action+"&task=getLastData",
					success: function(jsonData){
						$("#" + id_div).addClass('lof_load').html(jsonData.html);
					},
					error: function(XMLHttpRequest, textStatus, errorThrown) {alert("TECHNICAL ERROR: unable to save update quantity \n\nDetails:\nError thrown: " + XMLHttpRequest + "\n" + 'Text status: ' + textStatus);}
				});
			};
			// init
			var timeout;
			if(options.auto){;
				timeout = setTimeout(function(){
					getData(options.nextId);
					animate("next",false);
				},options.pause);
			};		
		
			if(!options.continuous && options.controlsFade){					
				$("#"+options.prevId).hide();
				$("#"+options.firstId).hide();				
			};				
			
		});
	  
	};

})(jQuery);



