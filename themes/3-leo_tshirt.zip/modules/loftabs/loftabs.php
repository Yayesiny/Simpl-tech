<?php
/**
 * $ModDesc
 * 
 * @version		$Id: file.php $Revision
 * @package		modules
 * @subpackage	$Subpackage.
 * @copyright	Copyright (C) December 2010 LandOfCoder.com <@emai:landofcoder@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
 */
if (!defined('_CAN_LOAD_FILES_')){
	define('_CAN_LOAD_FILES_',1);
}    
/**
 * lofcordion Class
 */	
class loftabs extends Module
{
	/**
	 * @var LofParams $_params;
	 *
	 * @access private;
	 */
	private $_params = '';	
	
	/**
	 * @var array $_postErrors;
	 *
	 * @access private;
	 */
	private $_postErrors = array();		
	
	/**
	 * @var string $__tmpl is stored path of the layout-theme;
	 *
	 * @access private 
	 */	
	
   /**
    * Constructor 
    */
	function __construct()
	{
		$this->name = 'loftabs';
		parent::__construct();			
		$this->tab = 'LandOfCoder';				
		$this->version = '1.5';
		$this->displayName = $this->l('Lof Tabs Module.');
		$this->description = $this->l('Lof Tabs Module.');
		$this->module_key  = "d1348ad5c9f20d9f56f22d2fbbeb3ae0";
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/params.php' ) && !class_exists("LofParams", false) ){
			if( !defined("LOF_LOAD_LIB_PARAMS") ){				
				require( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/params.php' );
				define("LOF_LOAD_LIB_PARAMS",true);
			}
		}
		$this->_params = new LofParams( $this->name );		   
	}
  
   /**
    * process installing 
    */
	function install(){		
		if (!parent::install())
			return false;
		if(!$this->registerHook('home'))
			return false;
		if(!$this->registerHook('header'))
			return false;	
		return true;
	}
	
    /*
    * Add Position for site
    */
    
    function hooklofPresDemo($params){
        return $this->processHook( $params,"lofPresDemo");
    }
    
    function hookloftab1($params){
        return $this->processHook( $params,"loftab1");
    }
	/*
	 * register hook right comlumn to display slide in right column
	 */
	function hookrightColumn($params)
	{		
		return $this->processHook( $params,"rightColumn");
	}
	
	/*
	 * register hook left comlumn to display slide in left column
	 */
	function hookleftColumn($params)
	{		
		return $this->processHook( $params,"leftColumn");
	}
	
	function hooktop($params)
	{		
		return $this->processHook( $params,"top");
	}
	
	function hookfooter($params)
	{		
		return $this->processHook( $params,"footer");
	}
	
	function hookcontenttop($params)
	{ 		
		return $this->processHook( $params,"contenttop");
	}
	
	
	function hookHeader($params)
	{
		if(_PS_VERSION_ <="1.4"){							
			$header = '
			<link type="text/css" rel="stylesheet" href="'.($this->_path).'tmpl/assets/style.css'.'" />
			<link type="text/css" rel="stylesheet" href="'.($this->_path).'tmpl/'. $this->getParamValue('module_theme','default').'/assets/style.css'.'" />			
			           <script type="text/javascript" src="'.($this->_path).'assets/jscript.js'.'"></script>';			
			return $header;			
		}elseif(_PS_VERSION_ < "1.5"){				
			Tools::addCSS( ($this->_path).'tmpl/assets/style.css', 'all');
			Tools::addCSS( ($this->_path).'tmpl/'. $this->getParamValue('module_theme','default').'/assets/style.css', 'all');
			Tools::addJS( ($this->_path).'assets/jscript.js', 'all');
			Tools::addJS( ($this->_path).'assets/jquery.tools.min.js', 'all');
		}else{
			$this->context->controller->addCSS( ($this->_path).'tmpl/assets/style.css', 'all');
			$this->context->controller->addCSS( ($this->_path).'tmpl/'. $this->getParamValue('module_theme','default').'/assets/style.css', 'all');
			$this->context->controller->addJS( ($this->_path).'assets/jscript.js', 'all');
			$this->context->controller->addJS( ($this->_path).'assets/jquery.tools.min.js', 'all');
		}		
	}
  		
  	
	function hooklofTop($params){
		return $this->processHook( $params,"lofTop");
	}
		
	function hookHome($params)
	{
		return $this->processHook( $params,"home");
	}
    
    function hookloftabs1($params){
		return $this->processHook( $params,"loftabs1");
	}
    
    function hookloftabs2($params){
		return $this->processHook( $params,"loftabs2");
	}
    
    function hookloftabs3($params){
		return $this->processHook( $params,"loftabs3");
	}
    
    function hookloftabs4($params){
		return $this->processHook( $params,"loftabs4");
	}
	
    
    function getListCatId( $parent_id ){
        global $cookie, $link;
		$id_lang = intval($cookie->id_lang);			
		$query = 'SELECT c.`id_category`, c.`id_parent`, cl.`name`, cl.`description`, cl.`link_rewrite`' .
				' FROM `'._DB_PREFIX_.'category` c' .
                ' LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON cl.`id_category` = c.`id_category` '.
				' WHERE c.id_category IN ('.$parent_id.') GROUP BY id_category';
		$result = Db::getInstance()->ExecuteS($query);
		return $result;
   }
    
	/**
	 * get list of subcategories by id
	 */
    function getListCategories($params, $idds){        
		global $cookie, $link;
		$id_lang = intval($cookie->id_lang);
		$ids = implode(",", $idds); 
		if($ids == ''){
			$where = ' WHERE `active` = 1 ';
		}else{
			$where = ' WHERE c.id_category IN ('.$ids.') ';
		}       
		$cate = array();				
		$query = 'SELECT c.`id_category`, c.`id_parent`, cl.`name`, cl.`description`, cl.`link_rewrite`, cl.`id_lang`' .
				' FROM `'._DB_PREFIX_.'category` c' .
				' LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON (cl.`id_category` = c.`id_category` AND cl.`id_lang` = '.(int)($id_lang).') '.
				$where.
				' GROUP BY id_category';
		$data = Db::getInstance()->ExecuteS($query);
		$ids = array();
		return $data;				
    }
	
	/**
	 * get list of Manu by id
	 */
    function getListManus($params){        
		global $cookie, $link;
		$id_lang = intval($cookie->id_lang);
		$ids = $params->get("manu","");
        if(!$ids) return array(); 
		
		$where = ' WHERE m.id_manufacturer IN ('.$ids.') ';
		
		$sql = 'SELECT m.*, ml.`description`';
		$sql.= ' FROM `'._DB_PREFIX_.'manufacturer` m
		LEFT JOIN `'._DB_PREFIX_.'manufacturer_lang` ml ON (m.`id_manufacturer` = ml.`id_manufacturer` AND ml.`id_lang` = '.(int)($id_lang).') '.$where;
		$sql.= ' ORDER BY m.`name` ASC';
		return Db::getInstance()->ExecuteS($sql);				
    }
	
	/**
    * Proccess module by hook
    * $pparams: param of module
    * $pos: position call
    */
	function processHook( $mparams, $pos="home" ){
        global $cookie, $link, $smarty;
       	$id_lang = (int)($cookie->id_lang);               
		//load param
		$params = $this->_params;
		$site_url = Tools::htmlentitiesutf8('http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__);
		
		if(_PS_VERSION_ <="1.4"){
			// create thumbnail folder	 						
			$thumbPath = _PS_IMG_DIR_.$this->name;
			
			if( !file_exists($thumbPath) ) {
				mkdir( $thumbPath, 0777 );			
			};
			$thumbUrl = $site_url."img/".$this->name;
		}else{
			// create thumbnail folder	 			
			$thumbPath = _PS_CACHEFS_DIRECTORY_.$this->name;
			if( !file_exists(_PS_CACHEFS_DIRECTORY_) ) {
				mkdir( _PS_CACHEFS_DIRECTORY_, 0777 );  			
			}; 
			if( !file_exists($thumbPath) ) {
				mkdir( $thumbPath, 0777 );			
			};
			$thumbUrl = $site_url."cache/cachefs/".$this->name;			
		}
		
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' ) && !class_exists("LofTabDataSourceBase", false) ){
			if( !defined("LOF_TAB_LOAD_LIB_GROUP") ) {
				require_once( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' );
				define("LOF_TAB_LOAD_LIB_GROUP",true);
			}
		}
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/phpthumb/ThumbLib.inc.php' ) && !class_exists('PhpThumbFactory', false)){						
			if( !defined("LOF_TAB_LOAD_LIB_PHPTHUMB") ) {
				require( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/phpthumb/ThumbLib.inc.php' );	
				define("LOF_TAB_LOAD_LIB_PHPTHUMB",true);
			}			
		}
        
        $moduleId = rand().time();
        $params->set( 'auto_renderthumb',0);
        $params->get("cre_main_size",1);
		$molTheme = $this->getParamValue('module_theme','default');
		$main_width_theme = $params->get("main_width",720);
        $tmp 			= $params->get( 'md_height', '800' );
		$moduleHeight   =  ( $tmp=='800' ) ? '800' : (int)$tmp;
		$tmp            = $params->get( 'md_width', '720' );
		$moduleWidth    =  ( $tmp=='720') ? '720': (int)$tmp;
		$theme 			= $params->get("module_theme","default");
		$target 	= $params->get( 'target', '_self' );		
		$class 			= $params->get( 'navigator_pos', 0 ) ? '':'lof-snleft';
		$blockid        = $this->id;
		
		$showTips 	   = $params->get('show_tips',"lof-none");
        $posActive   = $params->get("pos_act",0);
		$duration 	= $params->get('duration',500);
		$interval 	= $params->get('interval',2000);
		$lofeffect 	= $params->get('lofeffect',"");
        $limititem    = $params->get("limit_items",12);
        $showTooltip    = $params->get("show_tooltip",0);
        $showButton    = $params->get("show_button",1);
        $showImage    = $params->get("show_image",1);
        $showTitle    = $params->get("show_title",1);
        $showDesc    = $params->get("show_desc",1);
        $showPrice    = $params->get("show_price",1);
        $showPuplic    = $params->get("show_puplic",0);
        $showTipBox    = $params->get("show_box_tips",0);
        $readText    = $params->get("read_text","Readmore");
        //echo $limititem;die;
        $thumbmainWidth   = $params->get('main_width',220);
        $thumbmainHeight   = $params->get('main_height',330);
        $thumbnailWidth   = $params->get('thumb_width',430);
        $thumbnailHeight   = $params->get('thumb_height',200);
        $limitnumrows   = $params->get('limit_rows',2);
        $limitnumcols   = $params->get('limit_cols',3);	
        $autoPlay   = $params->get('auto_play',0);	
        $speed   = $params->get('speed',200);	
        $mergeCat   = $params->get('mer_cat',0);
        $priceSpecial   = $params->get('price_special',1);
        
        
        $featuredTab    = $params->get("featured_tab",0);
        $bestsellerTab    = $params->get("bestseller_tab",0);
        $enableCate    = $params->get("enableCate",0);
        
        $onlineIcon    = $params->get("online_icon",0);
        $featureIcon    = $params->get("feature_icon",0);
        $newIcon    = $params->get("new_icon",0);
        $saleIcon    = $params->get("sale_icon",0);
        
        $newTab    = $params->get("new_tab",1);
        $specialTab    = $params->get("special_tab",0);
		$enablemanu    = $params->get("enablemanu",0);
        $addclass = '';
        $addCssitem = 0;
        $loflistFeatureds  = "";
        $loflistFeatured = "";	
        $loflistSpecial = "";
        $loflistNewProduct = "";
        $loflistNewProducts = "";
        $cateUrlLayouts = "";
        $loflistBestseller = "";
        $loflistBestsellers = "";
        $loflistSpecials = "";
        $countitemperpage = $limitnumrows * $limitnumcols;        
     
        $selectCat = $params->get("category","");
        $checkversion = _PS_VERSION_;
        $ids  = explode(",",$selectCat);
        $token 				= Tools::getToken(false);
		$source =  	  'product';        
		$path = dirname(__FILE__).'/libs/groups/'.strtolower($source).'/product.php'; 				
		if( !file_exists($path) ){
			return array();	
		}
        require_once $path;
        $objectName = "LofTab".ucfirst($source)."DataSource";
	 	$object = new $objectName();
        $object->setThumbPathInfo($thumbPath,$thumbUrl)
               ->setImagesRendered( array( 'mainImage' => array( (int)$params->get( 'main_width', 220 ), (int)$params->get( 'main_height', 330 )) ) );
        
		$amountTabs = 0;
		$totalItems = 0;
		$homeFeature =  $this->getProFeature();
		$listloffeatureds = array();
        //get feature product
        $loflistFeatureds = array();
        if($featuredTab == 1 && $posActive == $amountTabs){
			$amountTabs++;
			$params->set($this->name.'_page', 0);
			$params->set($this->name.'_limit_items', $params->get("limit_items",10));
            $totalItems = count($object->getListFeatured( $params ));
			$params->set($this->name.'_limit_items', $countitemperpage);
            $listloffeatureds = $object->getListFeatured( $params );       
			$loflistFeatureds[0] = $listloffeatureds;
			$smarty->assign( array('lofloaded'=>'featuredTab'));
        }
		//get bestslller tab
        $loflistBS = array();
        if($bestsellerTab == 1 && $posActive == $amountTabs){
			$amountTabs++;
			$params->set($this->name.'_page', 0);
			$params->set($this->name.'_limit_items', $params->get("limit_items",10));
            $totalItems = count($object->getListBestSeller( $params, $homeFeature ));
			$params->set($this->name.'_limit_items', $countitemperpage);
            $loflistBS1 = $object->getListBestSeller( $params, $homeFeature );
			$loflistBS[0] = $loflistBS1;
			$smarty->assign( array('lofloaded'=>'bestsellerTab'));
        }
		
        if($specialTab == 1  && $posActive == $amountTabs){
			$amountTabs++;
			$params->set($this->name.'_page', 0);
			$params->set($this->name.'_limit_items', $params->get("limit_items",10));
            $totalItems = count($object->getListSpecial( $params,$homeFeature ));
			$params->set($this->name.'_limit_items', $countitemperpage);
            $loflistSpecial = $object->getListSpecial( $params, $homeFeature );
			$loflistSpecials[0] = $loflistSpecial;
			$smarty->assign( array('lofloaded'=>'specialTab'));
        }
		//new tab
        if($newTab == 1  && $posActive == $amountTabs){
			$amountTabs++;
			$params->set($this->name.'_page', 0);
			$params->set($this->name.'_limit_items', $params->get("limit_items",10));
            $totalItems = count($object->getListNewProduct( $params,$homeFeature ));
			$params->set($this->name.'_limit_items', $countitemperpage);
            $loflistNewProduct = $object->getListNewProduct( $params,$homeFeature );
           	
			$loflistNewProducts[0] = $loflistNewProduct;
			$smarty->assign( array('lofloaded'=>'newTab'));
        }
		//add manufacture
       $listProManu  = array();
	   $manus = array();
	   $listProManus = array(); 
	   $manuUrlLayouts = (dirname(__FILE__)).'/tmpl/_item/manu.tpl';	   
		if($enablemanu){	
			$params->set($this->name."_home_sorce","selectmanu");            
			$manus = $this->getListManus($params);
			foreach($manus as $manu){
				if($posActive == $amountTabs){
					$params->set($this->name.'_page', 0);
					$params->set($this->name.'_limit_items', $params->get("limit_items",10));
					$totalItems = count($object->getListByParameters( $params, $manu['id_manufacturer'], $countitemperpage, $homeFeature ));
					$params->set($this->name.'_limit_items', $countitemperpage);
					$listProManu = $object->getListByParameters( $params, $manu['id_manufacturer'], $countitemperpage, $homeFeature );
					$listProManus[$manu['id_manufacturer']] = $listProManu;
					$smarty->assign( array('lofloaded'=>'manu-'.$manu['id_manufacturer']));
				}
				$amountTabs++;
			}
			$params->set($this->name."_home_sorce","selectcat");
		}
        /*Edit 10/7/2011*/
        
        $module_width = $moduleWidth>0 ? "{$moduleWidth}" : "";
        if($moduleWidth != "auto"){
			$module_width = intval($module_width);
        }
        $countitemperpage = $limitnumrows * $limitnumcols;
        $totalwidththumb = (($thumbmainWidth+6) * $limitnumcols) + (20*($limitnumcols-1));
        if(($module_width < $totalwidththumb) && $module_width != "auto"){
        $module_width = $totalwidththumb;
        }
        $itemWidth = floor(9990/$limitnumcols)/100;        		
		
		//category
		$listlofproducts = array();		
		$cates = array();
		if($enableCate){
			$params->set($this->name."_home_sorce","selectcat");
			$cates =  $this->getListCategories($params, $ids);	
			foreach($cates as $cate){
				if($posActive == $amountTabs){
					$params->set($this->name.'_page', 0);
					$params->set($this->name.'_limit_items', $params->get("limit_items",10));
					$totalItems = count($object->getListByParameters( $params, $cate['id_category'], $countitemperpage, $homeFeature));
					
					$params->set($this->name.'_limit_items', $countitemperpage);
					$listproducts = $object->getListByParameters( $params, $cate['id_category'], $countitemperpage,$homeFeature);
					//echo "<pre>";print_r($listproducts);die;
					$listlofproducts[$cate['id_category']] = $listproducts;
					$smarty->assign( array('lofloaded'=>'cate-'.$cate['id_category']));
				}
				$amountTabs++;
			}
			$cateUrlLayouts = $this->lofItemLayout($theme,'categories.tpl');
        }
		$totalPages = ceil($totalItems/$countitemperpage);
         ob_start();
		    require( dirname(__FILE__).'/initjs.php' );		
    	    $initjs = ob_get_contents();
    	 ob_end_clean();
		
		
        $curLang = Language::getLanguage(intval($cookie->id_lang));
		$lofiso_code = $curLang["iso_code"];        
		// template asignment variables
		$smarty->assign( array(
                              'moduleId' => $moduleId,
							  'lofiso_code' => $lofiso_code,
						      'object'        => $object,
						      'showDesc'        => $showDesc,
						      'showPrice'        => $showPrice,
						      'showTipBox'        => $showTipBox,
						      'featuredTab'        => $featuredTab,
						      'bestsellerTab'        => $bestsellerTab,
                              'onlineIcon'        => $onlineIcon,
                              'featureIcon'        => $featureIcon,
                              'newIcon'        => $newIcon,
                              'saleIcon'        => $saleIcon,
                              'priceSpecial'        => $priceSpecial,
							  
						      'specialTab'        => $specialTab,
						      'loflistFeatureds'        => $loflistFeatureds,
						      'featuredUrlLayouts'        => $this->lofItemLayout($theme,'featured.tpl'),
						      'specialUrlLayouts'        => $this->lofItemLayout($theme,'special.tpl'),
						      
						      'loflistSpecials'        => $loflistSpecials,
							  
						      'loflistNewProducts'        => $loflistNewProducts,
						      'newProductsUrlLayouts'        => $this->lofItemLayout($theme,'newproduct.tpl'),
                              
						      'loflistBS'                => $loflistBS,
                              
                              
						      'bestSellerUrlLayouts'        => $this->lofItemLayout($theme,'bestseller.tpl'),
							  'manuUrlLayouts'    => $manuUrlLayouts,
						      'enableCate'        => $enableCate,
							  'enablemanu'        => $enablemanu,
						      'newTab'        => $newTab,
						      'addclass'        => $addclass,
						      'showTips'        => $showTips,
						      'addCssitem'        => $addCssitem,
						      'speed'        => $speed,
						      'cates'        => $cates,
							  //manu
							  'manus'        => $manus,
						      'checkversion'        => $checkversion,
						      'site_url'        => $site_url,
							  'countitemperpage' 		=> $countitemperpage,
							  'moduleHeight'     => $moduleHeight,
							  'moduleWidth'     => $moduleWidth,
							  'module_width'     => $module_width,
							  'autoPlay'     => $autoPlay,
							  'theme'	        => $theme,
							  'thumbmainWidth'      => $thumbmainWidth,
							  'thumbmainHeight'      => $thumbmainHeight,
                              'thumbnailWidth'      => $thumbnailWidth,
							  'thumbnailHeight'      => $thumbnailHeight,
							  'limitnumcols'      => $limitnumcols,
							  'mergeCat'      => $mergeCat,
							  'lofeffect'      => $lofeffect,
							  'interval'      => $interval,
							  'duration'      => $duration,
							  'itemWidth'      => $itemWidth,
							  
                              'token' 			=> $token,
                              'posActive' 			=> $posActive,
                              'showImage'		    => $showImage,
                              'readText'		    => $readText,
                              'target'		    => $target,
							  'perItemMinWidth'=>(int)$params->get( 'min_width_expanded', 196 ),
							  'showTooltip'    => $showTooltip,
							  'showButton'		=> $showButton,
							  'showPuplic'		=> $showPuplic,
							  'showTitle'=>$showTitle,
							  'listProManus'=>$listProManus,
							  'listProManu'=>$listProManu,
							  'pos'			=>$pos,
							  //image tab link
							  'feaimg'=>$params->get( 'feaimg', "" ),
							  'besimg'=>$params->get( 'besimg', "" ),
							  'newimg'=>$params->get( 'newimg', "" ),
							  'speimg'=>$params->get( 'speimg', "" ),
							  'mod_url'=>_MODULE_DIR_,
							  'mod_name'=> $this->name,
							  'totalPages' => $totalPages,
							  'cateUrlLayouts' => $cateUrlLayouts,
							  'firstAjax' => 1
						));
        $smarty->assign( array('listlofproducts' => $listlofproducts));
		return $this->display(__FILE__, $this->getLayoutPath($theme) ). $initjs;
	}
	
	public function processAjax($firstAjax = true, $type = "featured", $id_content = 0, $page = 0, $totalPages = 1){
        global $cookie, $link, $smarty;
       	$id_lang = (int)($cookie->id_lang);
		//load param
		$params = $this->_params;
		$site_url = Tools::htmlentitiesutf8('http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__);
		if(_PS_VERSION_ <="1.4"){
			// create thumbnail folder	 						
			$thumbPath = _PS_IMG_DIR_.$this->name;
			if( !file_exists($thumbPath) )
				mkdir( $thumbPath, 0777 );
			$thumbUrl = $site_url."img/".$this->name;
		}else{
			// create thumbnail folder	 			
			$thumbPath = _PS_CACHEFS_DIRECTORY_.$this->name;
			if( !file_exists(_PS_CACHEFS_DIRECTORY_) )
				mkdir( _PS_CACHEFS_DIRECTORY_, 0777 );
			if( !file_exists($thumbPath) )
				mkdir( $thumbPath, 0777 );
			$thumbUrl = $site_url."cache/cachefs/".$this->name;			
		}
		
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' ) && !class_exists("LofTabDataSourceBase", false) )
			if( !defined("LOF_TAB_LOAD_LIB_GROUP") ) {
				require_once( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' );
				define("LOF_TAB_LOAD_LIB_GROUP",true);
			}
		if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/phpthumb/ThumbLib.inc.php' ) && !class_exists('PhpThumbFactory', false))
			if( !defined("LOF_TAB_LOAD_LIB_PHPTHUMB") ) {
				require( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/phpthumb/ThumbLib.inc.php' );	
				define("LOF_TAB_LOAD_LIB_PHPTHUMB",true);
			}
        $moduleId = rand().time();
        $params->set( 'auto_renderthumb',0);
        $params->get("cre_main_size",1);
		$molTheme = $this->getParamValue('module_theme','default');
		$main_width_theme = $params->get("main_width",720);
        $tmp 			= $params->get( 'md_height', '800' );
		$moduleHeight   =  ( $tmp=='800' ) ? '800' : (int)$tmp;
		$tmp            = $params->get( 'md_width', '720' );
		$moduleWidth    =  ( $tmp=='720') ? '720': (int)$tmp;
		$theme 			= $params->get("module_theme","default");
		$target 	= $params->get( 'target', '_self' );		
		$class 			= $params->get( 'navigator_pos', 0 ) ? '':'lof-snleft';
		$blockid        = $this->id;
		$priceSpecial   = $params->get('price_special',1);
		$showTips 	   = $params->get('show_tips',"lof-none");
        $posActive   = $params->get("pos_act",0);
		$duration 	= $params->get('duration',500);
		$interval 	= $params->get('interval',2000);
		$lofeffect 	= $params->get('lofeffect',"");
        $limititem    = $params->get("limit_items",12);
        $showTooltip    = $params->get("show_tooltip",0);
        $showButton    = $params->get("show_button",1);
        $showImage    = $params->get("show_image",1);
        $showTitle    = $params->get("show_title",1);
        $showDesc    = $params->get("show_desc",1);
        $showPrice    = $params->get("show_price",1);
        $showPuplic    = $params->get("show_puplic",0);
        $showTipBox    = $params->get("show_box_tips",0);
        $readText    = $params->get("read_text","Readmore");
        //echo $limititem;die;
        $thumbmainWidth   = $params->get('main_width',220);
        $thumbmainHeight   = $params->get('main_height',330);
        $thumbnailWidth   = $params->get('thumb_width',430);
        $thumbnailHeight   = $params->get('thumb_height',200);
        $limitnumrows   = $params->get('limit_rows',2);
        $limitnumcols   = $params->get('limit_cols',3);	
        $autoPlay   = $params->get('auto_play',0);	
        $speed   = $params->get('speed',200);	
        $mergeCat   = $params->get('mer_cat',0);
		
        $onlineIcon    = $params->get("online_icon",0);
        $featureIcon    = $params->get("feature_icon",0);
        $newIcon    = $params->get("new_icon",0);
        $saleIcon    = $params->get("sale_icon",0);
        
        $countitemperpage = $limitnumrows * $limitnumcols;        
     
        $selectCat = $params->get("category","");
        $checkversion = _PS_VERSION_;
        $ids  = explode(",",$selectCat);
        $token 				= Tools::getToken(false);
		$source =  	  'product';        
		$path = dirname(__FILE__).'/libs/groups/'.strtolower($source).'/product.php'; 				
		if( !file_exists($path) )
			return array();	
        require_once $path;
        $objectName = "LofTab".ucfirst($source)."DataSource";
	 	$object = new $objectName();
        $object->setThumbPathInfo($thumbPath,$thumbUrl)->setImagesRendered( array( 'mainImage' => array( (int)$params->get( 'main_width', 220 ), (int)$params->get( 'main_height', 330 )) ) );
        
        $module_width = $moduleWidth>0 ? "{$moduleWidth}" : "";
        if($moduleWidth != "auto")
			$module_width = intval($module_width);
        $countitemperpage = $limitnumrows * $limitnumcols;
        $totalwidththumb = (($thumbmainWidth+6) * $limitnumcols) + (20*($limitnumcols-1));
        if(($module_width < $totalwidththumb) && $module_width != "auto")
			$module_width = $totalwidththumb;
        $itemWidth = floor(9990/$limitnumcols)/100;        		
		
		$smarty->assign( array(
			  'moduleId' => $moduleId,
			  'showDesc'        => $showDesc,
			  'showPrice'        => $showPrice,
			  'showTipBox'        => $showTipBox,
			  'onlineIcon'        => $onlineIcon,
			  'featureIcon'        => $featureIcon,
			  'newIcon'        => $newIcon,
			  'saleIcon'        => $saleIcon,
			  'priceSpecial'        => $priceSpecial,
			  
			  'showTips'        => $showTips,
			  'speed'        => $speed,
			  //manu
			  'checkversion'        => $checkversion,
			  'site_url'        => $site_url,
			  'moduleHeight'     => $moduleHeight,
			  'moduleWidth'     => $moduleWidth,
			  'module_width'     => $module_width,
			  'autoPlay'     => $autoPlay,
			  'theme'	        => $theme,
			  'thumbmainWidth'      => $thumbmainWidth,
			  'thumbmainHeight'      => $thumbmainHeight,
			  'thumbnailWidth'      => $thumbnailWidth,
			  'thumbnailHeight'      => $thumbnailHeight,
			  'limitnumcols'      => $limitnumcols,
			  'mergeCat'      => $mergeCat,
			  'lofeffect'      => $lofeffect,
			  'interval'      => $interval,
			  'duration'      => $duration,
			  'itemWidth'      => $itemWidth,
			  
			  'token' 			=> $token,
			  'posActive' 			=> $posActive,
			  'showImage'		    => $showImage,
			  'readText'		    => $readText,
			  'target'		    => $target,
			  'perItemMinWidth'=>(int)$params->get( 'min_width_expanded', 196 ),
			  'showTooltip'    => $showTooltip,
			  'showButton'		=> $showButton,
			  'showPuplic'		=> $showPuplic,
			  'showTitle'=>$showTitle,
			  //image tab link
			  'mod_url'=>_MODULE_DIR_,
			  'mod_name'=> $this->name,
			  'firstAjax' => (int)($firstAjax)
		));
		 ob_start();
		    require( dirname(__FILE__).'/ajax-js.php' );		
    	    $initjs = ob_get_contents();
    	 ob_end_clean();
		 
		$totalItems = 0;
		$homeFeature =  $this->getProFeature();
        //get feature product
        $loflistFeatureds = array();
        if($type == 'featured'){
			if($firstAjax){
				$params->set($this->name.'_page', 0);
				$params->set($this->name.'_limit_items', $params->get("limit_items",10));
				$totalItems = count($object->getListFeatured( $params ));
				$totalPages = ceil($totalItems/$countitemperpage);
			}
			$params->set($this->name.'_page', $page);
			$params->set($this->name.'_limit_items', $countitemperpage);
            $listloffeatureds = $object->getListFeatured( $params );       
			$loflistFeatureds[0] = $listloffeatureds;
			
			$smarty->assign( array('loflistFeatureds'=>$loflistFeatureds, 'totalPages' => $totalPages));
            return $this->display(__FILE__, 'tmpl/_item/featured.tpl').$initjs;
        }
		//get bestslller tab
        $loflistBS = array();
        if($type == 'bestseller'){
			if($firstAjax){
				$params->set($this->name.'_page', 0);
				$params->set($this->name.'_limit_items', $params->get("limit_items",10));
				$totalItems = count($object->getListBestSeller( $params, $homeFeature ));
				$totalPages = ceil($totalItems/$countitemperpage);
			}
			$params->set($this->name.'_page', $page);
			$params->set($this->name.'_limit_items', $countitemperpage);
			$loflistBS[0] = $object->getListBestSeller( $params, $homeFeature );
			
			$smarty->assign( array('loflistBS'=>$loflistBS, 'totalPages' => $totalPages));
            return $this->display(__FILE__, 'tmpl/_item/bestseller.tpl').$initjs;                        
        }
		
        if($type == 'special'){
			if($firstAjax){
				$params->set($this->name.'_page', 0);
				$params->set($this->name.'_limit_items', $params->get("limit_items",10));
				$totalItems = count($object->getListSpecial( $params,$homeFeature ));
				$totalPages = ceil($totalItems/$countitemperpage);
			}
			$params->set($this->name.'_page', $page);
			$params->set($this->name.'_limit_items', $countitemperpage);
			$loflistSpecials[0] = $object->getListSpecial( $params, $homeFeature );
			
			$smarty->assign( array('loflistSpecials'=>$loflistSpecials, 'totalPages' => $totalPages));
            return $this->display(__FILE__, 'tmpl/_item/special.tpl').$initjs;
        }
		//new tab
        if($type == 'new'){
			if($firstAjax){
				$params->set($this->name.'_page', 0);
				$params->set($this->name.'_limit_items', $params->get("limit_items",10));
				$totalItems = count($object->getListNewProduct( $params,$homeFeature ));
				$totalPages = ceil($totalItems/$countitemperpage);
			}
			$params->set($this->name.'_page', $page);
			$params->set($this->name.'_limit_items', $countitemperpage);
			$loflistNewProducts[0] = $object->getListNewProduct( $params,$homeFeature );
			
			$smarty->assign( array('loflistNewProducts'=>$loflistNewProducts, 'totalPages' => $totalPages));
            return $this->display(__FILE__, 'tmpl/_item/newproduct.tpl').$initjs;
        }
		//add manufacture
	    $manu = array();
	    $listProManus = array(); 		
		if($type == 'manu' && $id_content){
			$manu['id_manufacturer'] = $id_content;
			$params->set($this->name."_home_sorce","selectmanu");
			if($firstAjax){
				$params->set($this->name.'_page', 0);
				$params->set($this->name.'_limit_items', $params->get("limit_items",10));
				$totalItems = count($object->getListByParameters( $params, $id_content, $countitemperpage, $homeFeature ));
				$totalPages = ceil($totalItems/$countitemperpage);
			}
			$params->set($this->name.'_page', $page);
			$params->set($this->name.'_limit_items', $countitemperpage);
			$listProManus[$id_content] = $object->getListByParameters( $params, $id_content, $countitemperpage, $homeFeature );
			
			$smarty->assign( array('listProManus'=>$listProManus, 'totalPages' => $totalPages, 'manu' => $manu));
            return $this->display(__FILE__, 'tmpl/_item/manu.tpl').$initjs;
		}
        /*Edit 10/7/2011*/
		//category	
		if($type == 'cate' && $id_content){
			$cate['id_category'] = $id_content;
			$params->set($this->name."_home_sorce","selectcat");
			if($firstAjax){
				$params->set($this->name.'_page', 0);
				$params->set($this->name.'_limit_items', $params->get("limit_items",10));
				$totalItems = count($object->getListByParameters( $params, $id_content, $countitemperpage, $homeFeature));
				$totalPages = ceil($totalItems/$countitemperpage);
			}
			$params->set($this->name.'_page', $page);
			$params->set($this->name.'_limit_items', $countitemperpage);
			$listlofproducts[$id_content] = $object->getListByParameters( $params, $id_content, $countitemperpage, $homeFeature);
			$smarty->assign( array('listlofproducts'=>$listlofproducts, 'totalPages' => $totalPages, 'cate' => $cate));
            return $this->display(__FILE__, 'tmpl/_item/categories.tpl').$initjs;
        }
		
		return '';
	}
	
	public function lofItemLayout($theme, $fileName){
		if( file_exists(_PS_THEME_DIR_."modules/".$this->name."/tmpl/".$theme."/_item/".$fileName) ){
			return _PS_THEME_DIR_."modules/".$this->name."/tmpl/".$theme."/_item/".$fileName;
		}
		if( file_exists(_PS_THEME_DIR_."modules/".$this->name."/tmpl/_item/".$fileName) ){
			return _PS_THEME_DIR_."modules/".$this->name."/tmpl/_item/".$fileName;
		}
		if( file_exists((dirname(__FILE__)).'/tmpl/'.$theme.'/_item/'.$fileName) ){
			return (dirname(__FILE__)).'/tmpl/'.$theme.'/_item/'.$fileName;
		}
		return (dirname(__FILE__)).'/tmpl/_item/'.$fileName;
	}
	
	public function getLayoutPath( $theme ){
		if( file_exists((dirname(__FILE__)).'/tmpl/'.$theme.'/default.tpl') ){
			return 'tmpl/'.$theme.'/default.tpl';
		}
		
        return 'tmpl/default.tpl';
    }
	    
    
    public function splitingCols ( $products ){
        return $output; 
    }  
    
	public function deleteFileInFolder( $path ) {
		$items = array();
		$handle = opendir($path);
		if (! $handle) {
			return $items;
		}
		while (false !== ($file = readdir($handle))) {
			if (is_file($path . $file))
				unlink($path . $file);
		}
		return true;
	}
   /**
    * Get list of sub folder's name 
    */
	public function getFolderList( $path ) {
		$items = array();
		$handle = opendir($path);
		if (! $handle) {
			return $items;
		}
		while (false !== ($file = readdir($handle))) {
			if (is_dir($path . $file))
				$items[$file] = $file;
		}
		unset($items['.'], $items['..'], $items['.svn']);
		
		return $items;
	}
	
   /**
    * Render processing form && process saving data.
    */	
	public function getContent()
	{
		$html = "";
		if (Tools::isSubmit('submit'))
		{
			
			$this->_postValidation();
	
			if (!sizeof($this->_postErrors))
			{
				if(!Tools::getValue('cache')){
					$foldercache = _PS_MODULE_DIR_.$this->name.'/cache/';
					$this->deleteFileInFolder($foldercache);
				}
		        $definedConfigs = array(
		          /* general config */
		          'module_theme'      => '',
                  //image group
                  'module_group'      => '',
                  'image_folder'      => '',
                  'image_category'    => '',
                  'image_ordering'    => '',
                  'online_icon'       => '',
                  'feature_icon'      => '',
                  'new_icon'          => '',
                  'sale_icon'         => '',
                  'price_special'     => '',
                                                      
                  //product group
		          'home_sorce'        => '',
                  'featured_tab'      => '',
                  'bestseller_tab'    => '',
                  'new_tab'           => '',
                  'special_tab'      => '',
		          'show_tips'        => '',
		          'timenew'        => '',
                  'order_by'          => '',  
                  'limit_cols'          => '',  
                  'limit_rows'          => '',  
                  'enableCate'          => '',
				  'enablemanu'	        => '', 
                  'des_max_chars'     => '',                  
	              'productids'        => '',                  		          		          		                            		        
	              'pos_act'        => '',                  		          		          		                            		        
	              'show_box_tips'        => '',                  		          		          		                            		        
		          'read_text'            => 'readmore',
		          'speed'       => '200',
		          'md_height'     => '',
		          'md_width'      => '',
				  'delCaImg'	      => '',
				  'limit_items'       =>'',
		          /*Main CoinSlider Setting*/
                  'show_tooltip'           => '',
                  'show_button'           => '',
                  'show_image'            => '',
                  'show_desc'        => '',                                  		                            		          
		          'cre_main_size'     => '',
		          'main_img_size'     => '',
		          'main_height'       => '330',
		          'main_width'        => '220',
                  'thumb_height'       => '',
		          'thumb_width'        => '',
				  'auto_play' =>'',
		          /*Navigator Setting */
		          'show_price'     => '',
		          'show_title'     => '',
		          'show_puplic'=> '',
		          'mer_cat'=> '',
		          /*Effect Setting*/
		          'event'           => '',
		          'layout_style'      => '',
		          'spacing'          => '',
		          'duration'          => '',
		          'lofeffect'            => '',
                  'min_width_expanded'         => '',                  
		          'max_width_expanded'        => '',
		          'target'       =>'',
				  /*Customize Style*/
		          'enable_caption'    => '',
		          'caption_bg'        => '',
                  'caption_opacity'   => '',                  
                  'caption_fontcolor' => '',
                  'caption_linkcolor' => '',
                  'price_color'       => '',
                  'show_price'        => ''   , 
				  'file_path' => '',
				  // cache
				  'cache' => '',
				  'cache_time' => ''
		        );
				 for($i=1; $i<=10; $i++){
                    $definedConfigs[$i."-enable"]    = "";
                    if(Tools::getValue($i."-enable")){
                        $definedConfigs[$i."-filetype"]  = "";                                        
                        $definedConfigs[$i."-path"]      = "";
                        $definedConfigs[$i."-link"]      = "";                                                                            
                        $definedConfigs[$i."-timer"]     = "";
                        $definedConfigs[$i."-target"]    = "";
                        $definedConfigs[$i."-imagePos"]  = "";
                        $definedConfigs[$i."-pan"]       = "";
                        $definedConfigs[$i."-desc"]      = "";
                        $definedConfigs[$i."-title"]     = ""; 
                        $definedConfigs[$i."-preview"]   = "";
                        $definedConfigs[$i."-pan"]       = "";
                        $definedConfigs[$i."-imagePos"]  = "";
                        $definedConfigs[$i."-timer"]     = "";
                    }                                                          
                }
				
		        foreach( $definedConfigs as $config => $key ){
	 
		      		Configuration::updateValue($this->name.'_'.$config, Tools::getValue($config), true);
		    	}
                //$params->set( 'custom_id_parent', $ids );
                if(Tools::getValue('category')){
    		        if(in_array("",Tools::getValue('category'))){
    		          $catList = "";
    		        }else{
    		          $catList = implode(",",Tools::getValue('category'));  
    		        }
                    Configuration::updateValue($this->name.'_category', $catList, true);
                }
				//manu tab
				if(Tools::getValue('manu')){  		        
    		        $catList = implode(",",Tools::getValue('manu'));    		        
                    Configuration::updateValue($this->name.'_manu', $catList, true);
                }
				/*$arrCat = array("fecategory","becategory","necategory","spcategory");
				foreach($arrCat AS $cat){					
					if(Tools::getValue($cat)){
						if(in_array("",Tools::getValue($cat))){
						  $catList = "";
						}else{
						  $catList = implode(",",Tools::getValue($cat));  
						}
						Configuration::updateValue($this->name.'_'.$cat, $catList, true);
					}
				}*/
				
                $linkArray = Tools::getValue('override_links');
                if($linkArray){
                    foreach ($linkArray as $key => $value) {
                        if (is_null($value) || $value == "") {
                            unset ($linkArray[$key]);
                        }
                    }
                    $override_links = implode(",",$linkArray);
                    Configuration::updateValue($this->name.'_override_links', $override_links, true);
                }
				$delText = '';	
		        if(Tools::getValue('delCaImg')){					
					if(_PS_VERSION_ <="1.4"){						
						$cacheFol = _PS_IMG_DIR_.$this->name;												
					}else{			
						$cacheFol = _PS_CACHEFS_DIRECTORY_.$this->name;							
					}					
					if( file_exists( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' ) && !class_exists("LofTabDataSourceBase", false) ){
						if( !defined("LOF_LOAD_LIB_GROUP") ) {
							require_once( _PS_ROOT_DIR_.'/modules/'.$this->name.'/libs/group_base.php' );
							define("LOF_LOAD_LIB_GROUP",true);
						}
					}
					if (LofDataSourceBase::removedir($cacheFol)){
						$delText =  $this->l('. Cache folder has been deleted');
					}else{
						$delText =  $this->l('. Cache folder can\'tdeleted');
					}  
				}
		        $html .= '<div class="conf confirm">'.$this->l('Settings updated').$delText.'</div>';
			}
			else
			{
				foreach ($this->_postErrors AS $err)
				{
					$html .= '<div class="alert error">'.$err.'</div>';
				}
			}
			// reset current values.
			$this->_params = new LofParams( $this->name );	
		}
			
		return $html.$this->_getFormConfig();
	}
	
	/**
	 * Render Configuration From for user making settings.
	 *
	 * @return context
	 */
	private function _getFormConfig(){		
		$html = '';
		 
	    $formats = ImageType::getImagesTypes( 'products' );
	    $themes=$this->getFolderList( dirname(__FILE__)."/tmpl/" );
        $groups=$this->getFolderList( dirname(__FILE__)."/libs/groups/" );

	    ob_start();
	    include_once dirname(__FILE__).'/config/loftabs.php'; 
	    $html .= ob_get_contents();
	    ob_end_clean(); 
		return $html;
	}
    
	/**
     * Process vadiation before saving data 
     */
	private function _postValidation()
	{
		if (!Validate::isCleanHtml(Tools::getValue('module_height')))
			$this->_postErrors[] = $this->l('The module height you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('module_width')))
			$this->_postErrors[] = $this->l('The module width you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('des_max_chars')) || !is_numeric(Tools::getValue('des_max_chars')))
			$this->_postErrors[] = $this->l('The description max chars you entered was not allowed, sorry');
		
		if (!Validate::isCleanHtml(Tools::getValue('main_height')) || !is_numeric(Tools::getValue('main_height')))
			$this->_postErrors[] = $this->l('The Main Image Height you entered was not allowed, sorry');
		if (!Validate::isCleanHtml(Tools::getValue('main_width')) || !is_numeric(Tools::getValue('main_width')))
			$this->_postErrors[] = $this->l('The Main Image Width you entered was not allowed, sorry');
 
                      							
	}
	
	public function getProFeature(){
		$sql = 'SELECT DISTINCT p.id_product FROM `'._DB_PREFIX_.'category_product` cp '
		 . 'LEFT JOIN `'._DB_PREFIX_.'product` p ON p.`id_product` = cp.`id_product` '
		 . 'WHERE cp.`id_category` =1';    
		return Db::getInstance()->ExecuteS($sql);
	} 	 
        
	
   /**
    * Get value of parameter following to its name.
    * 
	* @return string is value of parameter.
	*/
	public function getParamValue($name, $default=''){
		return $this->_params->get( $name, $default );	
	}	  	  		
} 