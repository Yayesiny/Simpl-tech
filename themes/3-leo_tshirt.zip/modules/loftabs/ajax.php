<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');
include(dirname(__FILE__).'/loftabs.php');
global $cookie;
$objTabs = new loftabs();
if(Tools::getValue('task','getFirstData') == 'getFirstData'){
	$data = Tools::getValue('data');
	if(!$data)
		die('');
	$datas = explode('-',$data);
	if(count($datas) < 2)
		die('');
	echo $objTabs->processAjax(true, $datas[0], $datas[1]);
	die;
}
if(Tools::getValue('task') == 'getLastData'){
	$data = Tools::getValue('data');
	if(!$data)
		die('');
	$datas = explode('-',$data);
	if(count($datas) < 2)
		die('');
	$page = Tools::getValue('page');
	$totalages = Tools::getValue('totalpage');
	$html =  $objTabs->processAjax(false, $datas[0], $datas[1], $page, $totalages);
	$jsonData['totalages'] = $totalages;
	$jsonData['page'] = $page;
	$jsonData['html'] = $html;
	die(json_encode($jsonData));
}