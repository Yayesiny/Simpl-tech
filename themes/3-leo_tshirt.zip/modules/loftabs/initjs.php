<script type="text/javascript">
// <![CDATA[
	// we hide the tree only if JavaScript is activated
	var ajaxUrl = "<?php echo $site_url.'modules/'.$this->name.'/ajax.php'?>";
	var lofmarginleft = new Array();
	var lofwidth = new Array();
	var lofindex = new Array();
	var currentTab = '';
	
jQuery(document).ready(function() {
       jQuery("#lof-tabnews-module-<?php echo $moduleId;?>").loftabs({
    	       positionActive: <?php echo $params->get("pos_act",0);?>,
    	       moduleId: '<?php echo $moduleId;?>',
               continuous: false
	   });
	   
		$(window).bind('resize', function () { 
			var width = $("#lof-tabnews-module-<?php echo $moduleId;?> .lof-content-tab:visible").width();
			$("#lof-tabnews-module-<?php echo $moduleId;?> .lof-content-tab").each(function(i){
				var loftab = false;
				for(var i = 0; i < lofatabs.length; i++){
					if($(this).hasClass(lofatabs[i])){
						loftab = lofatabs[i];
					}
				}
				
				var total_width = 0;
				$(this).find('.lof-container ul li').each(function(){
					$(this).width(width);
					total_width += width;
				});
				var margin_left = lofmarginleft[loftab] + (lofwidth[loftab] - width)*lofindex[loftab];
				$(this).find('.lof-container ul').width(total_width);
				if(lofmarginleft[loftab] != 0){
					
					$(this).find('.lof-container ul').css('margin-left', margin_left+'px');
				}
			});
		});
});
    
// ]]>
</script>