<script language="javascript">

//when document is loaded...
$(document).ready(function(){

	$('.ajax_add_to_cart_button').unbind('click').click(function(){
		var idProduct =  $(this).attr('rel').replace('ajax_id_product_', '');
		if ($(this).attr('disabled') != 'disabled')
			ajaxCart.add(idProduct, null, false, this);
		return false;
	});
});
</script>
<?php
if( $showTips == "lof-tooltip" AND $checkversion >= '1.4'){ ?>
<script type="text/javascript">  
	jQuery(document).ready(function() {
			jQuery(".lof-tool-item-<?php echo $moduleId;?>").tooltip({
				effect: 'slide',
				offset: [0, 2],
				onBeforeShow:	function(event, position) {
								this.getTip().appendTo(document.body);
								return true;}}
			);
			
   });
</script>
<?php 
} 
?>