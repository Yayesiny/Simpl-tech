$(document).ready( function(){
      
    $('#cms_form').submit( function () {
    	return false; 
    } );

} ); 
