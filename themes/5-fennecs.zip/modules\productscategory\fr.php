<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}prestashop>productscategory_db33983df8ef521000b0ab60dcb5a83f'] = 'Dans la même catégorie';
$_MODULE['<{productscategory}prestashop>productscategory_c167dc9a6cdefdab35fb3b5e325cc815'] = 'Affiche la liste des produits dans la même catégorie que celui affiché';
