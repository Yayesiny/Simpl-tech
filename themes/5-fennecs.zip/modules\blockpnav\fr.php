<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpnav}prestashop>blockpnav_a0f17ef01e569e92f9d6e91288a1b294'] = 'Produit précédent';
$_MODULE['<{blockpnav}prestashop>blockpnav_b1afaa3aa4110c54791e61e8a8e7b7ee'] = 'Produit suivant';
