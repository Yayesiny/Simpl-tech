<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_9e31b08a00c1ed653bcaa517dee84714'] = 'Bloc newsletter';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_e95e612048e381ba2b1f310e07d1b1a3'] = 'Ajoute un bloc newsletter pour vos clients';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_179bbcbd2e1104cdf9dcecd91264a961'] = 'Etes-vous sûr de vouloir supprimer tous vos contacts ?';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_f0e9c1e3969d351170373b5cec2131c2'] = 'Code de réduction invalide';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_3f9b87832191fff1d2136c2c2d699e76'] = 'Mise à jour terminée.';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_948f6c829388992fb60b74b55d4c9cc4'] = 'Afficher la configuration dans une nouvelle page ?';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_a6105c0a611b41b08f1209506350279e'] = 'Oui';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_7fa3b767c460b54a2be4d49030b349c7'] = 'Non';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_e6c433ce875a8034672996e8aff25fc2'] = 'Envoyer un mail de confirmation après inscription ?';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_506e58042922bff5bd753dc612e84f5b'] = 'Code de réduction offert';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_de3bd7faad12c79178b1b22bf6119e35'] = 'Laissez vide pour désactiver';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_06933067aafd48425d67bcb01bba5cb6'] = 'Mise à jour';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_6e659c47c94d1e1dc7121859f43fb2b0'] = 'Adresse e-mail invalide';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_9e6df6e72be5be5b8ff962ee3406907e'] = 'Adresse e-mail introuvable';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_29003419c075963848f1907174bdc224'] = 'Erreur lors de la désinscription';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_f7dc297e2a139ab4f5a771825b46df43'] = 'Votre désinscription est effective';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_8dc3b88902df97bb96930282e56ed381'] = 'Adresse e-mail déjà inscrite';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_b7d9eb38dd2e375648ab08e224e22e43'] = 'Une erreur est survenue lors de votre inscription';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_ed3cd7b3cc134222fa70602921ec27e1'] = 'Votre inscription est effective';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_a95bc59685fb4546de3884a5fbe474ea'] = 'Réduction de la lettre d\'information';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_efabbb0eb84d3c8e487a72e879953673'] = 'Confirmation de la lettre d\'information';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_416f61a2ce16586f8289d41117a2554e'] = 'votre e-mail';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_b26917587d98330d93f87808fc9d7267'] = 'Inscription';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_4182c8f19d40c7ca236a5f4f83faeb6b'] = 'Désinscription';
