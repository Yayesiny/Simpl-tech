<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Bloc nouveaux produits';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_2dabfba3a3ebc0a7e4728f08ba165d1e'] = 'Ajoute un bloc proposant les derniers produits ajoutés';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_be3695bcf32c0086aa98108330d9bfa1'] = 'Vous devez remplir le champ \"produit affiché\"';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Nombre invalide.';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour effectuée';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_e451e6943bb539d1bd804d2ede6474b5'] = 'Nombre de produits affichés';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_cc4bbebd6a8d2fb633a1dd8ceda3fc8d'] = 'Détermine le nombre de produits à afficher dans ce bloc';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveautés';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_453d11d297e3318a9112039e9a41ef3d'] = 'voir tout';
$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_d3cf1fa1c9e0e3187f9156ae8c121d06'] = 'Pas de nouveau produit pour le moment';
