<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}prestashop>productscategory_0cda5eb528bd661aedb9429d131dea4b'] = 'Similars products';

?>
