  $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
	
      $('.flexslider').flexslider({
        animation: "fade",
		animationLoop:true,
		slideshowSpeed: 3000, 
		animationSpeed: 500,
		
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
	      $('.brandslogoes').flexslider({
        animation: "slide",
        animationLoop: true,
        itemWidth: 188,
        itemMargin: 0,
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
	  
    });