<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zoomslider}prestashop>zoomslider_152e6e6cc352750a6fb6bf8a8eeac4f5'] = 'Zoom Slider JQuery';
$_MODULE['<{zoomslider}prestashop>zoomslider_a642b86f659d63dd9eb4edcecc13f571'] = 'Deslize as imagens com efeito de zoom';
$_MODULE['<{zoomslider}prestashop>zoomslider_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Ocorreu um erro durante o carregamento da imagem.';
$_MODULE['<{zoomslider}prestashop>zoomslider_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Não é possível gravar o arquivo de editor.';
$_MODULE['<{zoomslider}prestashop>zoomslider_8072bc856691062b88d30354ab28a27a'] = 'Não é possível fechar o arquivo editor.';
$_MODULE['<{zoomslider}prestashop>zoomslider_93314199c1f5be182040fd88370f44f4'] = 'Não foi possível atualizar o arquivo de editor. Por favor, verifique as permissões do arquivo do editor de redação.';
$_MODULE['<{zoomslider}prestashop>zoomslider_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmação';
$_MODULE['<{zoomslider}prestashop>zoomslider_c888438d14855d7d96a2724ee9c306bd'] = 'Configurações atualizados';
$_MODULE['<{zoomslider}prestashop>zoomslider_363049596ccc3fc70d40d96609440652'] = 'Deslizar #';
$_MODULE['<{zoomslider}prestashop>zoomslider_495bc3ee1e44cfd8ea290d068ce693dd'] = 'Imagem do slide';
$_MODULE['<{zoomslider}prestashop>zoomslider_2dc64b725ff04bf97d5e27ec8e313f17'] = 'URL de slides';
$_MODULE['<{zoomslider}prestashop>zoomslider_cc8d94d20adb22355773a2aed823eb3c'] = 'Deslize dica';
$_MODULE['<{zoomslider}prestashop>zoomslider_099af53f601532dbd31e0ea99ffdeb64'] = 'excluir';
$_MODULE['<{zoomslider}prestashop>zoomslider_9b838ba01e3eddffba8bb08a0c60513b'] = 'Seu arquivo de links é vazio.';
$_MODULE['<{zoomslider}prestashop>zoomslider_34ec78fcc91ffb1e54cd85e4a0924332'] = 'adicionar';
$_MODULE['<{zoomslider}prestashop>zoomslider_786dbe52d294816a3044824f03980135'] = 'Adicionar um novo slide';
$_MODULE['<{zoomslider}prestashop>zoomslider_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
