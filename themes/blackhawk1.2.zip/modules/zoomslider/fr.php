<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zoomslider}prestashop>zoomslider_152e6e6cc352750a6fb6bf8a8eeac4f5'] = 'JQuery Zoom Slider';
$_MODULE['<{zoomslider}prestashop>zoomslider_a642b86f659d63dd9eb4edcecc13f571'] = 'Faites glisser les images avec effet de zoom';
$_MODULE['<{zoomslider}prestashop>zoomslider_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Une erreur s\'est produite lors de l\'envoi d\'images.';
$_MODULE['<{zoomslider}prestashop>zoomslider_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Impossible d\'écrire dans le fichier de l\'éditeur.';
$_MODULE['<{zoomslider}prestashop>zoomslider_8072bc856691062b88d30354ab28a27a'] = 'Impossible de fermer le fichier de l\'éditeur.';
$_MODULE['<{zoomslider}prestashop>zoomslider_93314199c1f5be182040fd88370f44f4'] = 'Impossible de mettre à jour le fichier de l\'éditeur.  S\'il vous plaît vérifier les autorisations de l\'écriture du fichier de l\'éditeur.';
$_MODULE['<{zoomslider}prestashop>zoomslider_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_MODULE['<{zoomslider}prestashop>zoomslider_c888438d14855d7d96a2724ee9c306bd'] = 'Les préférences de mise à jour';
$_MODULE['<{zoomslider}prestashop>zoomslider_363049596ccc3fc70d40d96609440652'] = 'Diapositive #';
$_MODULE['<{zoomslider}prestashop>zoomslider_495bc3ee1e44cfd8ea290d068ce693dd'] = 'Faites glisser l\'image';
$_MODULE['<{zoomslider}prestashop>zoomslider_2dc64b725ff04bf97d5e27ec8e313f17'] = 'URL Slide';
$_MODULE['<{zoomslider}prestashop>zoomslider_cc8d94d20adb22355773a2aed823eb3c'] = 'Slide tooltip';
$_MODULE['<{zoomslider}prestashop>zoomslider_099af53f601532dbd31e0ea99ffdeb64'] = 'supprimer';
$_MODULE['<{zoomslider}prestashop>zoomslider_9b838ba01e3eddffba8bb08a0c60513b'] = 'Votre dossier est vide liens.';
$_MODULE['<{zoomslider}prestashop>zoomslider_34ec78fcc91ffb1e54cd85e4a0924332'] = 'Ajouter';
$_MODULE['<{zoomslider}prestashop>zoomslider_786dbe52d294816a3044824f03980135'] = 'Ajouter une nouvelle diapositive';
$_MODULE['<{zoomslider}prestashop>zoomslider_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
