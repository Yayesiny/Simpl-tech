<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zoomslider}prestashop>zoomslider_152e6e6cc352750a6fb6bf8a8eeac4f5'] = 'JQuery Zoom Slider';
$_MODULE['<{zoomslider}prestashop>zoomslider_a642b86f659d63dd9eb4edcecc13f571'] = 'Far scorrere le immagini con effetto zoom';
$_MODULE['<{zoomslider}prestashop>zoomslider_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'È verificato un errore durante il caricamento delle immagini.';
$_MODULE['<{zoomslider}prestashop>zoomslider_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Impossibile scrivere nel file editor.';
$_MODULE['<{zoomslider}prestashop>zoomslider_8072bc856691062b88d30354ab28a27a'] = 'Impossibile chiudere il file editor.';
$_MODULE['<{zoomslider}prestashop>zoomslider_93314199c1f5be182040fd88370f44f4'] = 'Impossibile aggiornare il file editor. Si prega di controllare i permessi di scrittura del file dell\'editore.';
$_MODULE['<{zoomslider}prestashop>zoomslider_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Conferma';
$_MODULE['<{zoomslider}prestashop>zoomslider_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornato';
$_MODULE['<{zoomslider}prestashop>zoomslider_363049596ccc3fc70d40d96609440652'] = 'diapositiva  #';
$_MODULE['<{zoomslider}prestashop>zoomslider_495bc3ee1e44cfd8ea290d068ce693dd'] = 'diapositiva immagine';
$_MODULE['<{zoomslider}prestashop>zoomslider_2dc64b725ff04bf97d5e27ec8e313f17'] = 'diapositiva URL';
$_MODULE['<{zoomslider}prestashop>zoomslider_cc8d94d20adb22355773a2aed823eb3c'] = 'Far scorrere tooltip';
$_MODULE['<{zoomslider}prestashop>zoomslider_099af53f601532dbd31e0ea99ffdeb64'] = 'Cancellare';
$_MODULE['<{zoomslider}prestashop>zoomslider_9b838ba01e3eddffba8bb08a0c60513b'] = 'Il file link è vuoto.';
$_MODULE['<{zoomslider}prestashop>zoomslider_34ec78fcc91ffb1e54cd85e4a0924332'] = 'aggiungere';
$_MODULE['<{zoomslider}prestashop>zoomslider_786dbe52d294816a3044824f03980135'] = 'Aggiungere una nuova diapositiva';
$_MODULE['<{zoomslider}prestashop>zoomslider_c9cc8cce247e49bae79f15173ce97354'] = 'salvare';
