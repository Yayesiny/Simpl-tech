<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontactinfos}touchmenot1.0.3>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Contattaci';
$_MODULE['<{blockcontactinfos}touchmenot1.0.3>blockcontactinfos_d0398e90769ea6ed2823a3857bcc19ea'] = 'Tel:';
$_MODULE['<{blockcontactinfos}touchmenot1.0.3>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'E-mail:';
