<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}touchmenot1.0.3>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Prodotti in Evidenza';
$_MODULE['<{homefeatured}touchmenot1.0.3>homefeatured_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuovo';
$_MODULE['<{homefeatured}touchmenot1.0.3>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Non ci sono prodotti in vetrina';
