<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_12641546686fe11aaeb3b3c43a18c1b3'] = 'Tu Carrito de Compras';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_7fc68677a16caa0f02826182468617e6'] = 'Carrito:';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_f5bf48aa40cad7891eb709fcf1fde128'] = 'producto';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_86024cad1e83101d97359d7351051156'] = 'productos';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(Vacío)';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Su cuenta';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Bienvenido';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Cerrar mi sesión';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Finalizar la sesión';
$_MODULE['<{blockuserinfo}touchmenot1.0.3>blockuserinfo_bffe9a3c9a7e00ba00a11749e022d911'] = 'Iniciar la sesión';
