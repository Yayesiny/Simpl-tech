<?php
$query = " 
-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2012 at 03:30 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE=\"NO_AUTO_VALUE_ON_ZERO\";
SET time_zone = \"+00:00\";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `update_shoes`
--

-- --------------------------------------------------------

--
-- Table structure for table `_DB_PREFIX_loffc_block`
--

DROP TABLE IF EXISTS `_DB_PREFIX_loffc_block`;
CREATE TABLE IF NOT EXISTS `_DB_PREFIX_loffc_block` (
  `id_loffc_block` int(11) NOT NULL AUTO_INCREMENT,
  `width` float(10,2) NOT NULL,
  `show_title` tinyint(1) NOT NULL,
  `id_position` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_loffc_block`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `_DB_PREFIX_loffc_block`
--

INSERT INTO `_DB_PREFIX_loffc_block` (`id_loffc_block`, `width`, `show_title`, `id_position`) VALUES
(46, 20.00, 1, 2),
(54, 20.00, 1, 2),
(55, 20.00, 1, 2),
(56, 20.00, 1, 2),
(57, 50.00, 1, 1),
(58, 50.00, 1, 1),
(59, 20.00, 1, 2),
(60, 50.00, 1, 3),
(61, 50.00, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `_DB_PREFIX_loffc_block_item`
--

DROP TABLE IF EXISTS `_DB_PREFIX_loffc_block_item`;
CREATE TABLE IF NOT EXISTS `_DB_PREFIX_loffc_block_item` (
  `id_loffc_block_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_loffc_block` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `link` varchar(2000) NOT NULL,
  `linktype` varchar(25) NOT NULL,
  `link_content` varchar(2000) NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `hook_name` varchar(100) NOT NULL,
  `latitude` varchar(25) NOT NULL,
  `longitude` varchar(25) NOT NULL,
  `addthis` tinyint(1) NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `target` varchar(20) NOT NULL DEFAULT '_self',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id_loffc_block_item`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=106 ;

--
-- Dumping data for table `_DB_PREFIX_loffc_block_item`
--

INSERT INTO `_DB_PREFIX_loffc_block_item` (`id_loffc_block_item`, `id_loffc_block`, `type`, `link`, `linktype`, `link_content`, `module_name`, `hook_name`, `latitude`, `longitude`, `addthis`, `show_title`, `target`, `position`) VALUES
(86, 57, 'module', '', '', '', 'blocknewsletter', 'displayleftcolumn', '', '', 0, 1, '', 0),
(89, 58, 'module', '', '', '', 'lofsocial', 'displayfooter', '', '', 0, 0, '', 0),
(90, 46, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 0),
(91, 54, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 0),
(92, 55, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 0),
(93, 56, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 0),
(95, 59, 'module', '', '', '', 'blocklanguages', 'displaytop', '', '', 0, 1, '', 0),
(97, 60, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 0),
(98, 61, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 0),
(100, 59, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 2),
(103, 57, 'custom_html', '', '', '', '', '', '', '', 0, 1, '', 1),
(105, 59, 'module', '', '', '', 'blockcurrencies', 'displaytop', '', '', 0, 1, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `_DB_PREFIX_loffc_block_item_lang`
--

DROP TABLE IF EXISTS `_DB_PREFIX_loffc_block_item_lang`;
CREATE TABLE IF NOT EXISTS `_DB_PREFIX_loffc_block_item_lang` (
  `id_loffc_block_item` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
	PRIMARY KEY (`id_loffc_block_item`,`id_lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `_DB_PREFIX_loffc_block_item_lang`
--

INSERT INTO `_DB_PREFIX_loffc_block_item_lang` (`id_loffc_block_item`, `id_lang`, `title`, `text`) VALUES
(0, 1, 'item 1', ''),
(0, 2, 'item 1', ''),
(0, 3, 'item 1', ''),
(0, 4, 'item 1', ''),
(0, 5, 'item 1', ''),
(0, 6, 'item 1', ''),
(86, 1, 'To Newsletter', ''),
(86, 2, 'Newsletter', ''),
(86, 3, 'Newsletter', ''),
(86, 4, 'Newsletter', ''),
(86, 5, 'Newsletter', ''),
(89, 1, 'Follow Us', ''),
(89, 2, 'Follow Us', ''),
(89, 3, 'Follow Us', ''),
(89, 4, 'Follow Us', ''),
(89, 5, 'Follow Us', ''),
(90, 1, 'About us', '<div id=\"about_us\">\r\n<ul>\r\n<li><a href=\"index.php?id_cms=4&amp;controller=cms\">About Us</a></li>\r\n<li><a href=\"#\">Customer Service</a></li>\r\n<li><a href=\"#\">Privacy Policy</a></li>\r\n<li><a href=\"#\">Infomation </a></li>\r\n</ul>\r\n</div>'),
(90, 2, 'About us', ''),
(90, 3, 'About us', ''),
(90, 4, 'About us', ''),
(90, 5, 'About us', ''),
(91, 1, 'Customer Services', '<div id=\"custom_s\">\r\n<ul>\r\n<li><a>Shipping &amp; Returns</a></li>\r\n<li><a>Secure Shopping</a></li>\r\n<li><a href=\"index.php?controller=contact\">Contact us</a></li>\r\n</ul>\r\n</div>'),
(91, 2, 'Customer Services', ''),
(91, 3, 'Customer Services', ''),
(91, 4, 'Customer Services', ''),
(91, 5, 'Customer Services', ''),
(92, 1, 'Terms & Conditions', '<div id=\"terms\">\r\n<ul>\r\n<li><a>Press Room</a></li>\r\n<li><a>Help</a></li>\r\n<li><a>Terms &amp; Conditions</a></li>\r\n<li><a>Shipping</a></li>\r\n</ul>\r\n</div>'),
(92, 2, 'Terms & Conditions', ''),
(92, 3, 'Terms & Conditions', ''),
(92, 4, 'Terms & Conditions', ''),
(92, 5, 'Terms & Conditions', ''),
(93, 1, 'My Account', '<div id=\"my_account\">\r\n<ul>\r\n<li><a href=\"index.php?controller=authentication&amp;back=my-account\">My Account</a></li>\r\n<li><a>Order History</a></li>\r\n<li><a>Wish List</a></li>\r\n<li><a>Newsletter</a></li>\r\n</ul>\r\n</div>'),
(93, 2, 'My Account', ''),
(93, 3, 'My Account', ''),
(93, 4, 'My Account', ''),
(93, 5, 'My Account', ''),
(95, 1, 'Language', ''),
(95, 2, 'll', ''),
(95, 3, 'll', ''),
(95, 4, 'll', ''),
(95, 5, 'll', ''),
(97, 1, 'copyright', '<p>Copyright &copy 2012 LeoShoes. All Rights Reserved</p>'),
(97, 2, 'copyright', ''),
(97, 3, 'copyright', ''),
(97, 4, 'copyright', ''),
(97, 5, 'copyright', ''),
(98, 1, 'design', '<p><a href=\"http://www.leotheme.com/\">Design by Leotheme</a></p>'),
(98, 2, 'design', ''),
(98, 3, 'design', ''),
(98, 4, 'design', ''),
(98, 5, 'design', ''),
(100, 1, 'logo', ''),
(100, 2, 'logo', ''),
(100, 3, 'logo', ''),
(100, 4, 'logo', ''),
(100, 5, 'logo', ''),
(103, 1, 'Login', '<p><a class=\"login-footer\" href=\"http://localhost/prestashop/index.php?controller=my-account\">Sign up</a></p>'),
(103, 2, 'Login', ''),
(103, 3, 'Login', ''),
(103, 4, 'Login', ''),
(103, 5, 'Login', ''),
(105, 1, 'crs', ''),
(105, 2, 'crs', ''),
(105, 3, 'crs', ''),
(105, 4, 'crs', ''),
(105, 5, 'crs', '');

-- --------------------------------------------------------

--
-- Table structure for table `_DB_PREFIX_loffc_block_item_shop`
--

DROP TABLE IF EXISTS `_DB_PREFIX_loffc_block_item_shop`;
CREATE TABLE IF NOT EXISTS `_DB_PREFIX_loffc_block_item_shop` (
  `id_loffc_block_item` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL,
  PRIMARY KEY (`id_loffc_block_item`,`id_shop`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `_DB_PREFIX_loffc_block_item_shop`
--

INSERT INTO `_DB_PREFIX_loffc_block_item_shop` (`id_loffc_block_item`, `id_shop`) VALUES
(86, 1),
(89, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(95, 1),
(97, 1),
(98, 1),
(100, 1),
(103, 1),
(105, 1);

-- --------------------------------------------------------

--
-- Table structure for table `_DB_PREFIX_loffc_block_lang`
--

DROP TABLE IF EXISTS `_DB_PREFIX_loffc_block_lang`;
CREATE TABLE IF NOT EXISTS `_DB_PREFIX_loffc_block_lang` (
  `id_loffc_block` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
   PRIMARY KEY (`id_loffc_block`,`id_lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `_DB_PREFIX_loffc_block_lang`
--

INSERT INTO `_DB_PREFIX_loffc_block_lang` (`id_loffc_block`, `id_lang`, `title`) VALUES
(55, 6, 'About Dropship'),
(55, 5, 'About Dropship'),
(55, 4, 'About Dropship'),
(54, 4, 'My Account'),
(54, 3, 'My Account'),
(54, 2, 'My Account'),
(54, 1, 'My Account'),
(55, 3, 'About Dropship'),
(55, 2, 'About Dropship'),
(55, 1, 'About Dropship'),
(54, 6, 'My Account'),
(54, 5, 'My Account'),
(46, 6, 'block 3'),
(46, 5, 'block 3'),
(46, 4, 'block 3'),
(46, 3, 'block 3'),
(46, 1, 'About us'),
(46, 2, 'block 3'),
(56, 4, 'Infomation'),
(56, 5, 'Infomation'),
(56, 6, 'Infomation'),
(56, 3, 'Infomation'),
(56, 1, 'Infomation'),
(56, 2, 'Infomation'),
(57, 1, 'Newsletter'),
(57, 2, 'Newsletter'),
(57, 3, 'Newsletter'),
(57, 4, 'Newsletter'),
(57, 5, 'Newsletter'),
(58, 1, 'Follow Us'),
(58, 2, 'Follow Us'),
(58, 3, 'Follow Us'),
(58, 4, 'Follow Us'),
(58, 5, 'Follow Us'),
(59, 1, 'Language'),
(59, 2, 'Language'),
(59, 3, 'Language'),
(59, 4, 'Language'),
(59, 5, 'Language'),
(60, 1, 'copyright'),
(60, 2, 'copyright'),
(60, 3, 'copyright'),
(60, 4, 'copyright'),
(60, 5, 'copyright'),
(61, 1, 'design'),
(61, 2, 'design'),
(61, 3, 'design'),
(61, 4, 'design'),
(61, 5, 'design');

-- --------------------------------------------------------

--
-- Table structure for table `_DB_PREFIX_loffc_block_shop`
--

DROP TABLE IF EXISTS `_DB_PREFIX_loffc_block_shop`;
CREATE TABLE IF NOT EXISTS `_DB_PREFIX_loffc_block_shop` (
  `id_loffc_block` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL,
  PRIMARY KEY (`id_loffc_block`,`id_shop`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `_DB_PREFIX_loffc_block_shop`
--

INSERT INTO `_DB_PREFIX_loffc_block_shop` (`id_loffc_block`, `id_shop`) VALUES
(46, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


";
?>